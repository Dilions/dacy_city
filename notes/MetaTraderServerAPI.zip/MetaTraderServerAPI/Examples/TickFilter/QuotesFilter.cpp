//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "QuotesFilter.h"

extern CServerInterface   *ExtServer;
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CTickHistory::CTickHistory(const ConSymbol *symbol,const int len): m_bid_middle(0),m_ask_middle(0),m_next(NULL)
  {
//---
   if(symbol!=NULL) memcpy(&m_symbol,symbol,sizeof(m_symbol));
   else             memset(&m_symbol,0,sizeof(m_symbol));
//---
   if((m_ticks=new FeedTick[len])!=NULL) m_ticks_max=len;
   else                                  m_ticks_max=0;
   m_ticks_total=0;
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CTickHistory::~CTickHistory()
  {
//--- delete history
   if(m_ticks!=NULL) { delete[] m_ticks; m_ticks=NULL; }
   m_ticks_total=0;
//--- delete next symbol
   if(m_next!=NULL) { delete m_next; m_next=NULL; }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CTickHistory::Tick(FeedTick *inf,const double level)
  {
   double range,delta;
   char   tmp[512];
//---
   if(m_ticks_total>=m_ticks_max)
     {
      memmove(m_ticks,&m_ticks[8],sizeof(FeedTick)*(m_ticks_total-8));
      m_ticks_total-=8;
     }
   memcpy(&m_ticks[m_ticks_total++],inf,sizeof(FeedTick));
//--- ������������ �������
   m_ask_middle=m_bid_middle=0;
   for(int i=0;i<m_ticks_total;i++)
     {
      m_bid_middle+=m_ticks[i].bid;
      m_ask_middle+=m_ticks[i].ask;
     }
   m_bid_middle/=m_ticks_total;
   m_ask_middle/=m_ticks_total;
//--- ��������� �� ����
   range=m_bid_middle*level;            // ���������� ������ ���������
   delta=fabs(m_bid_middle-inf->bid);   // ���������� ����������
   if(delta>range)
     {
      _snprintf(tmp,sizeof(tmp)-1,"%s %.5lf / %.5lf [%d, limit by bid, price deviation: %.5lf, max deviation: %.5lf]",
                                m_symbol.symbol,inf->bid,inf->ask,inf->feeder,delta,range);
      if(ExtServer!=NULL) ExtServer->LogsOut(CmdErr,"TickFilter",tmp);
      m_ticks_total--;
      return(FALSE);
     }
//--- ��������� �� ����
   range=m_ask_middle*level;  // ���������� ������ ���������
   delta=fabs(m_bid_middle-inf->ask);   // ���������� ����������
   if(delta>range)
     {
      _snprintf(tmp,sizeof(tmp)-1,"%s %.5lf / %.5lf [%d, limit by ask, price deviation: %.5lf, max deviation: %.5lf]",
                                m_symbol.symbol,inf->bid,inf->ask,inf->feeder,delta,range);
      if(ExtServer!=NULL) ExtServer->LogsOut(CmdErr,"TickFilter",tmp);
      m_ticks_total--;
      return(FALSE);
     }
//--- �� ������...
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CQuotesFilter::CQuotesFilter() : m_history(NULL),
                                 m_filter_len(HIST_FILTER_LEN),
                                 m_filter_level(HIST_FILTER_LEV),
                                 m_reinitialize_flag(0)
  {
  }
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CQuotesFilter::~CQuotesFilter()
  {
   m_sync.Lock();
//---
   if(m_history!=NULL) { delete m_history; m_history=NULL; }
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Reading of config file                                           |
//+------------------------------------------------------------------+
void CQuotesFilter::Initialize()
  {
   char tmp[256];
//--- read
   ExtConfig.GetInteger("Filter History Length",&m_filter_len,   "64");
   ExtConfig.GetDouble("Filter Level"          ,&m_filter_level,"0.2");
//--- checking
   if(m_filter_len<1)                           m_filter_len=HIST_FILTER_LEN;
   if(m_filter_level<0.05 || m_filter_level>=1) m_filter_level=0.2;
//--- notify
   if(ExtServer!=NULL)
     {
      _snprintf(tmp,sizeof(tmp)-1,"initialized [%d history len, %.2lf filter channel]",m_filter_len,m_filter_level);
      ExtServer->LogsOut(CmdOK,"TickFilter",tmp);
     }
//---
  }
//+------------------------------------------------------------------+
//| �������� ���������                                               |
//+------------------------------------------------------------------+
int CQuotesFilter::Check(const ConSymbol *symbol,FeedTick *inf)
  {
   CTickHistory *next;
//--- ��������
   if(symbol==NULL || inf==NULL) return(FALSE);
   m_sync.Lock();
//--- ����� �������
   next=m_history;
   while(next!=NULL)
     {
      if(next->Check(symbol->symbol)==0) break;
      next=next->Next();
     }
//--- if not found
   if(next==NULL)
     {
      //--- allocate new symbol
      if((next=new CTickHistory(symbol,m_filter_len))==NULL)
        {
         m_sync.Unlock();
         return(TRUE);
        }
      //--- insert at the first position
      next->Next(m_history);
      m_history=next;
     }
//--- check new price
   int res=next->Tick(inf,m_filter_level);
//---
   m_sync.Unlock();
   return(res);
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

//---
#define HIST_FILTER_LEN   64
#define HIST_FILTER_LEV 0.15
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CTickHistory
  {
private:
   ConSymbol         m_symbol;
   FeedTick         *m_ticks;
   int               m_ticks_total;
   int               m_ticks_max;
   double            m_bid_middle;
   double            m_ask_middle;
   CTickHistory     *m_next;

public:
                     CTickHistory(const ConSymbol *symbol,const int len);
                    ~CTickHistory();

   CTickHistory*     Next()                    { return(m_next); }
   void              Next(CTickHistory *next)  { m_next=next;    }
   inline int        Check(LPCSTR symbol) { return strcmp(m_symbol.symbol,symbol); }
   int               Tick(FeedTick *inf,const double level);
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CQuotesFilter
  {
private:
   CSync             m_sync;                   // ������������� �������
   CTickHistory     *m_history;                // ������� ���������
   //--- ��������� ����������
   int               m_filter_len;             // ����� ����������� �������
   double            m_filter_level;           // ������ ������ � ���������
   LONG              m_reinitialize_flag;      //

public:
                     CQuotesFilter();
                    ~CQuotesFilter();

   void              Initialize();
   inline void       Reinitialize() { InterlockedExchange(&m_reinitialize_flag,1); }
   int               Check(const ConSymbol *symbol,FeedTick *inf);
  };
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//| Simple socket                                                    |
//+------------------------------------------------------------------+
class CRawSocket
  {
protected:
   SOCKET            m_socket;

public:
                     CRawSocket(void);
                    ~CRawSocket() { Close(); }
   //---
   int               Connect(LPCSTR server);
   void              Close(void);
   //---
   inline SOCKET     Socket() const { return(m_socket); }
   int               IsReadible();
   int               IsWritible();
   inline int        IsConnected(void) const { return(m_socket==INVALID_SOCKET ? FALSE:TRUE); }
   //---
   int               SendString(char *buf,int len);
   int               ReadString(char *buf,int maxlen);
  };
//+------------------------------------------------------------------+

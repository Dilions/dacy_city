//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "socket.h"

const timeval ExtSocketTimeout={ 0,0 };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CRawSocket::CRawSocket(void): m_socket(INVALID_SOCKET)
  {
  }
//+------------------------------------------------------------------+
//| Close socket                                                     |
//+------------------------------------------------------------------+
void CRawSocket::Close(void)
  {
//---
   if(m_socket!=INVALID_SOCKET)
     {
      shutdown(m_socket,2);
      closesocket(m_socket);
      m_socket=INVALID_SOCKET;
     }
//---
  }
//+------------------------------------------------------------------+
//| Connect                                                          |
//+------------------------------------------------------------------+
int CRawSocket::Connect(LPCSTR server)
  {
   unsigned int       addr,srvport=4444;
   struct sockaddr_in srv;
   struct hostent    *hp;
   char              *cp,tmp[256];
//--- check
   if(server==NULL) return(FALSE);
   Close();
//--- parse server address
   COPY_STR(tmp,server);
   if((cp=strstr(tmp,":"))!=NULL) { *cp=0; srvport=atoi(cp+1); }
//--- connect
   if((m_socket=socket(AF_INET, SOCK_STREAM,IPPROTO_TCP))==INVALID_SOCKET) return(FALSE);
//---
   ZeroMemory(&srv,sizeof(srv));
   srv.sin_family=AF_INET;
   if((addr=inet_addr(tmp))==INADDR_NONE)
     {
      if((hp=gethostbyname(tmp))==NULL) { Close(); return(FALSE); }
      srv.sin_addr.s_addr=*((unsigned long*)hp->h_addr);
     }
   else srv.sin_addr.s_addr=addr;
   srv.sin_port=htons(srvport);
//--- ������������
   if(connect(m_socket,(struct sockaddr*)&srv,sizeof(srv))!=0) { Close(); return(FALSE); }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Check bytes in input buffer                                      |
//+------------------------------------------------------------------+
int CRawSocket::IsReadible()
  {
   unsigned long size=0;
//---
   if(m_socket!=INVALID_SOCKET)
     if(ioctlsocket(m_socket,FIONREAD,&size)!=0) { Close(); size=0; }
//---
   return(size);
  }
//+------------------------------------------------------------------+
//|  Check bytes in output buffer                                    |
//+------------------------------------------------------------------+
int CRawSocket::IsWritible()
  {
   if(m_socket==INVALID_SOCKET) return(FALSE);
//---
   fd_set  fds;
   fds.fd_count=1;
   fds.fd_array[0]=m_socket;
//---
   int nStatus=select(0,NULL,&fds,NULL,&ExtSocketTimeout);
   if(nStatus==SOCKET_ERROR || nStatus==0) { Close(); return(FALSE); }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Send data                                                        |
//+------------------------------------------------------------------+
int CRawSocket::SendString(char *buf,int len)
  {
   int   res,count=10;
//--- check
   if(m_socket==INVALID_SOCKET || buf==NULL || len<0) return(FALSE);
//---
   if(len==0) len=strlen(buf);
//--- send data
   while(len>0)
     {
      if((res=send(m_socket,buf,len,0))<1)
        {
         //--- socket blocked?
         if(WSAGetLastError()==WSAEWOULDBLOCK)
           if(--count>0) { Sleep(100); continue; }
         Close();
         return(FALSE);
        }
      buf+=res; len-=res;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Read string from socket                                          |
//+------------------------------------------------------------------+
int CRawSocket::ReadString(char *buf,int maxlen)
  {
   int count=10,total=0;
//--- check
   if(m_socket==INVALID_SOCKET || buf==NULL || maxlen<1) return(FALSE);
//--- read data
   while(maxlen>0)
     {
      if(recv(m_socket,buf,1,0)!=1)
        {
         //--- socket blocked?
         if(WSAGetLastError()==WSAEWOULDBLOCK)
           if(--count>0) { Sleep(100); continue; }
         *buf=0; Close(); return(-1);
        }
      if(*buf=='\r') continue;
      if(*buf=='\n') break;
      maxlen--; buf++; total++;
     }
   *buf=0;
//---
   return(total);
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#define             PLUGIN_TRADES_ID      (1111111)
#define             PLUGIN_BASE_VERSION   (100)
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#pragma pack(push,1)
struct OrdersPair
  {
   int               order;
   int               coverage_order;
  };
#pragma pack(pop)
//+------------------------------------------------------------------+
//| Automated adding processed orders on coverage aaccount           |
//+------------------------------------------------------------------+
class CCoverageBase
  {
   CSync             m_sync;               // synchonizer
   OrdersPair       *m_orders;             // hedged orders base
   int               m_orders_total;       // hedged orders total
   int               m_orders_max;         // hedged orders max
   UserInfo          m_coverage;
public:
                     CCoverageBase();
                    ~CCoverageBase();
   //---
   void             Initialize();
   void             Save();
   void             TradeAdd(TradeRecord *trade,const UserInfo *user,const ConSymbol *symb);
   void             TradeClose(TradeRecord *trade,UserInfo *user,const int mode);

private:
   int              TradeCacheAdd(const int order,const int hedge_order);
   void             TradeCacheRemove(OrdersPair* pair);
   //---
   static int       SortByOrder(const void *left,const void *right);
   static int       SearchByOrder(const void *left,const void *right);
  };
extern CCoverageBase ExtCoverageBase;
//+------------------------------------------------------------------+

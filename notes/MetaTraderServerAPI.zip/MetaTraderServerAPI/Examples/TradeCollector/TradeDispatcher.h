//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
#include "socket.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#define MAX_TRADES     128
#define MAX_REQUEST    256
#define MAX_WAIT_TIME  120000
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct SymbolTick;
//---
struct TradeInfo
  {
   char              symbol[12];            // symbol name
   int               cmd;                   // OP_BUY or OP_SELL
   double            volume;                // volume
   double            price;                 // price
  };
//---
struct TradesCfg
  {
   char              server[64];              // server address and port (localhost:4444)
   char              login[32];               // login
   char              password[32];            // password
  };
//---
struct TradeRequest
  {
   int               request_id;
   int               status;
   int               result;
   HANDLE            complete_event;
  };
//---
enum { REQ_EMPTY, REQ_REQUEST };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CTradeDispatcher
  {
private:
   CSync             m_sync;                // synchonizer
   TradesCfg         m_cfg;                 // configuration
   //--- quotes base
   TradeInfo         m_trades[MAX_TRADES];  // queue
   int               m_trades_total;        // total records
   //--- quote pumping
   CRawSocket        m_socket;              // socket
   HANDLE            m_thread;              // thread
   volatile int      m_finished;            // stop flag
   //--- request base
   TradeRequest      m_requests[MAX_REQUEST];  // request base
   int               m_requests_total;         // request base size

public:
                     CTradeDispatcher(void);
                    ~CTradeDispatcher(void);
   //---
   void              Initialize(void);
   void              Start(void);
   void              Shutdown(void);
   int               Process(RequestInfo *request,SymbolTick *tick);
   //---
   TradeRequest*     RequestFindFree();
   void              RequestReply(char* str);
   void              RequestFree();
   //--- pumping thread
   static UINT __stdcall ThreadProc(LPVOID lParam);
   void                  PumpThread(void);
  };

extern CTradeDispatcher ExtTradesDispatcher;
//+------------------------------------------------------------------+

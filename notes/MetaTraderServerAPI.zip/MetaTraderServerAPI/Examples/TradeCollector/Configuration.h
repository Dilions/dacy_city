//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//| Plugin configuration processing class                            |
//+------------------------------------------------------------------+
class CConfiguration
  {
protected:
   PluginCfg*        m_cfg;
   int               m_cfg_total,m_cfg_max;
   char              m_cfgname[64];  // ��� �����
   CSync             m_sync;
public:
                     CConfiguration();
                    ~CConfiguration();
   //--- ������������� ���� (������ ������ �����)
   int               Add(const PluginCfg* cfg);
   int               Set(const PluginCfg *values,const int total);
   int               Get(LPCSTR name,PluginCfg* cfg);
   int               Next(const int index,PluginCfg* cfg);
   int               Delete(LPCSTR name);
   int               Total() { m_sync.Lock(); int total=m_cfg_total; m_sync.Unlock(); return(total); }

protected:
   void              Load();
   void              Save();
   virtual void      Reload() {}
   static int        SortByName(const void *left,const void *right);
   static int        SearchByName(const void *left,const void *right);
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

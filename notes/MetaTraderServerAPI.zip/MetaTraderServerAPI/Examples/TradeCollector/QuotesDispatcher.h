//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

#include "socket.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct SymbolTick
  {
   char              symbol[12];
   double            bid,ask;
   time_t            expiration;
   time_t            value_date;
   char              rate_id[33];
  };
struct QuotesCfg
  {
   char              server[64];              // server address and port (localhost:4444)
   char              login[32];               // login
   char              password[32];            // password
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CQuotesDispatcher
  {
private:
   CSync             m_sync;                // synchonizer
   QuotesCfg         m_cfg;                 // configuration
   //--- quotes base
   SymbolTick        m_quotes[MAX_SYMBOLS]; // quotes base
   int               m_quotes_total;        // quotes total
   //--- quote pumping
   CRawSocket        m_socket;              // socket
   HANDLE            m_thread;              // thread
   volatile int      m_finished;            // stop flag

public:
                     CQuotesDispatcher(void);
                    ~CQuotesDispatcher(void);
   //---
   void              Initialize(void);
   void              Start(void);
   void              Shutdown(void);
   int               QuotesGet(LPCSTR symbol,SymbolTick *tick);
   int               CheckPrice(RequestInfo *request,SymbolTick *tick);
   int               CorrectStopsPrice(TradeRecord *trade,SymbolTick *tick,const int isTP);
   int               CorrectPendingsPrice(const TradeRecord *pending,TradeRecord *trade,SymbolTick *tick);
   int               CorrectStopoutPrice(TradeRecord *trade,SymbolTick *tick);
private:
   void              QuoteParse(char *str);
   int               QuoteAdd(const SymbolTick* tick);
   //--- pumping thread
   static UINT __stdcall ThreadProc(LPVOID lParam);
   void                  PumpThread(void);
  };
extern CQuotesDispatcher ExtQuotesDispatcher;
//+------------------------------------------------------------------+

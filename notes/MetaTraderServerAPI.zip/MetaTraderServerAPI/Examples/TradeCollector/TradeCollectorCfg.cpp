//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "TradeCollectorCfg.h"
#include "Misc\Common.h"

CTradeCollectorCfg ExtConfig;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CTradeCollectorCfg::CTradeCollectorCfg()
  {
   m_trades_server[0]  =0;
   m_trades_login[0]   =0;
   m_trades_password[0]=0;
//---
   m_quotes_server[0]  =0;
   m_quotes_login[0]   =0;
   m_quotes_password[0]=0;
//---
   m_coverage_account=0;
//---
   m_takeprofit_slippage=m_stoploss_slippage=m_pendings_slippage=2;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CTradeCollectorCfg::~CTradeCollectorCfg()
  {
   Save();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CTradeCollectorCfg::Initialize(const char *cfgname)
  {
   m_sync.Lock();
   if(cfgname!=NULL) { COPY_STR(m_cfgname,cfgname); Load(); }
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CTradeCollectorCfg::Reload()
  {
   PluginCfg cfg;
//---
   if(Get("QuotesServer"  ,    &cfg)!=FALSE)  COPY_STR(m_trades_server, cfg.value);
   if(Get("QuotesLogin"   ,    &cfg)!=FALSE)  COPY_STR(m_trades_login, cfg.value);
   if(Get("QuotesPassword",    &cfg)!=FALSE)  COPY_STR(m_trades_password, cfg.value);
//---
   if(Get("TradeServer"  ,    &cfg)!=FALSE)  COPY_STR(m_quotes_server,  cfg.value);
   if(Get("TradeLogin"   ,    &cfg)!=FALSE)  COPY_STR(m_quotes_login,   cfg.value);
   if(Get("TradePassword",    &cfg)!=FALSE)  COPY_STR(m_quotes_password,cfg.value);
//---
   if(Get("CoverageAccount",  &cfg)!=FALSE)  m_coverage_account=atoi(cfg.value);
//---
   if(Get("TPSlippage" ,&cfg)!=FALSE)        m_takeprofit_slippage=atoi(cfg.value);
   if(Get("SLSlippage" ,&cfg)!=FALSE)        m_stoploss_slippage  =atoi(cfg.value);
   if(Get("PendingsSlippage" ,&cfg)!=FALSE)  m_pendings_slippage  =atoi(cfg.value);
//---
  }
//+------------------------------------------------------------------+

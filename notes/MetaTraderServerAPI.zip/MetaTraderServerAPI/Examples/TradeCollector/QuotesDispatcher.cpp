//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Logger.h"
#include "misc\common.h"
#include "QuotesDispatcher.h"
#include "TradeCollectorCfg.h"

CQuotesDispatcher        ExtQuotesDispatcher;
extern CServerInterface *ExtServer;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CQuotesDispatcher::CQuotesDispatcher(void) : m_quotes_total(0),m_thread(NULL),m_finished(FALSE)
  {
//---
   ZeroMemory(m_quotes,sizeof(m_quotes));
   ZeroMemory(&m_cfg,sizeof(m_cfg));
   COPY_STR(m_cfg.server,"localhost:4444");
   COPY_STR(m_cfg.login,"QUOTES");
   COPY_STR(m_cfg.password,"PASSWORD");
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CQuotesDispatcher::~CQuotesDispatcher(void)
  {
   Shutdown();
  }
//+------------------------------------------------------------------+
//| Read configuration                                               |
//+------------------------------------------------------------------+
void CQuotesDispatcher::Initialize(void)
  {
   char  tmp[256],*cp;
   FILE *in;
//--- construct config filename
   GetModuleFileName(NULL,tmp,sizeof(tmp)-1);
   if((cp=strrchr(tmp, '.'))!=NULL) *cp=0;
   strcat(tmp,".cfg");
//--- open file and read all lines
   m_sync.Lock();
   if((in=fopen(tmp,"rt"))!=NULL)
     {
      while(fgets(tmp,250,in)!=NULL)
        {
         ClearLF(tmp);
         if(tmp[0]==';') continue;
         //--- parse lines
         if(GetStrParam(tmp,"ServerQuotes="  ,m_cfg.server  ,sizeof(m_cfg.server)-1)  ==TRUE) continue;
         if(GetStrParam(tmp,"LoginQuotes="   ,m_cfg.login   ,sizeof(m_cfg.login)-1)   ==TRUE) continue;
         if(GetStrParam(tmp,"PasswordQuotes=",m_cfg.password,sizeof(m_cfg.password)-1)==TRUE) continue;
        }
      fclose(in);
     }
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Start pumping thread                                             |
//+------------------------------------------------------------------+
void CQuotesDispatcher::Start(void)
  {
   DWORD     ret;
   UINT      id=0;
   ConSymbol symb;
//---
   Initialize();
   m_sync.Lock();
//--- check thread
   if(m_thread!=NULL)
     {
      GetExitCodeThread(m_thread,&ret);
      if(ret!=STILL_ACTIVE) { CloseHandle(m_thread); m_thread=NULL; }
     }
//--- load symbols
   if(ExtServer!=NULL)
     while(ExtServer->SymbolsNext(m_quotes_total,&symb)!=FALSE)
       {
        COPY_STR(m_quotes[m_quotes_total].symbol,symb.symbol);
        m_quotes_total++;
       }
//--- start thread
   if(m_thread==NULL)
     m_thread=(HANDLE)_beginthreadex(NULL,256000,ThreadProc,(void*)this,0,&id);
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Shutdown pumping thread                                          |
//+------------------------------------------------------------------+
void CQuotesDispatcher::Shutdown(void)
  {
//--- close socket
   m_sync.Lock();
   m_socket.SendString("LOGOUT\r\n",8);
   m_finished=TRUE;
   m_socket.Close();
   m_sync.Unlock();
//--- terminate thread
   if(m_thread!=NULL)
     {
      WaitForSingleObject(m_thread,INFINITE);
      CloseHandle(m_thread);
      m_thread=NULL;
     }
//---
  }
//+------------------------------------------------------------------+
//| Thread entry point                                               |
//+------------------------------------------------------------------+
UINT __stdcall CQuotesDispatcher::ThreadProc(LPVOID lParam)
  {
//---
   CQuotesDispatcher *pThis=reinterpret_cast<CQuotesDispatcher*>(lParam);
   if(pThis!=NULL) pThis->PumpThread();
//---
   return(0);
  }
//+------------------------------------------------------------------+
//| Quotes pumping thread                                            |
//+------------------------------------------------------------------+
void CQuotesDispatcher::PumpThread(void)
  {
   char     tmp[256];
//--- loop until finished
   while(m_finished==FALSE)
     {
      //--- connect
      if(m_socket.Connect(m_cfg.server)==FALSE)
        {
         ExtLogger.Out(CmdErr,NULL,"Quotes: connection error %s",m_cfg.server);
         Sleep(1000);
         continue;
        }
      //--- switch to quotes
      _snprintf(tmp,sizeof(tmp)-1,"LOGIN %s %s\n",m_cfg.login,m_cfg.password);
      if(m_socket.SendString(tmp,0)==FALSE)
        {
         m_socket.Close();
         ExtLogger.Out(CmdErr,NULL,"Quotes: switch error");
         Sleep(1000);
         continue;
        }
      //--- read quotes
      while(m_finished==FALSE)
        {
         if(m_socket.ReadString(tmp,sizeof(tmp)-1)<0)
           {
            m_socket.Close();
            ExtLogger.Out(CmdErr,NULL,"Quotes: read error");
            Sleep(1000);
            break;
           }
         //--- parse
         if(memcmp(tmp,"QUOTE",5)==0) QuoteParse(tmp+6);
         if(memcmp(tmp,"EOF",3)==0)   ExtLogger.Out(CmdOK,NULL,"QuotesDispatcher: DB is out");
         if(memcmp(tmp,"ERROR",5)==0) ExtLogger.Out(CmdErr,NULL,"QuotesDispatcher: DB error - %s",tmp+1);
        }
      //--- send logout notification
      m_socket.SendString("LOGOUT\r\n",8);
      //--- close socket
      m_socket.Close();
     }
//---
  }
//+------------------------------------------------------------------+
//| Parse quote                                                      |
//| QUOTE symbol, bid, ask, expiry time in sec, valueDate, rateId    |
//+------------------------------------------------------------------+
void CQuotesDispatcher::QuoteParse(char *str)
  {
   char       *cp,*ep;
   FeedData    data={0};
   SymbolTick  tick={0};
   tm          ttm ={0};
//---
   if(str==NULL)                   return;
//--- parse symbol
   if((cp=strchr(str,','))==NULL)  return;
   *cp=0;
   COPY_STR(data.ticks[0].symbol,str);
   COPY_STR(tick.symbol,str);
//--- parse bid
   if((ep=strchr(cp+2,','))==NULL) return;
   *ep=0;
   tick.bid=data.ticks[0].bid=atof(cp+2);
//--- parse ask
   if((cp=strchr(ep+2,','))==NULL) return;
   *cp=0;
   tick.ask=data.ticks[0].ask=atof(ep+2);
//--- parse expiration
   if((ep=strchr(cp+2,','))==NULL) return;
   *ep=0;
   tick.expiration=atol(cp+2);
//--- parse value date (YYYY-MM-DD)
//--- parse year
   ttm.tm_year=atol(ep+2)-1900;
//--- parse month
   if((cp=strchr(ep+2,'-'))==NULL) return;
   ttm.tm_mon=atol(cp+1)-1;
//--- parse day
   if((ep=strchr(cp+1,'-'))==NULL) return;
   ttm.tm_mday=atol(ep+1);
   tick.value_date=mktime(&ttm);
//--- parse rate id
   if((cp=strchr(ep,','))==NULL) return;
   COPY_STR(tick.rate_id,cp+2);
//--- add quote to our internal Market Watch table
   if(QuoteAdd(&tick)==TRUE)
     {
      //--- push quote in server
      data.feeder     =0;    // feeder index
      data.ticks_count=1;    // quote count
      ExtServer->HistoryAddTick(&data);
     }
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CQuotesDispatcher::QuoteAdd(const SymbolTick* tick)
  {
//--- check parameters
   if(tick==NULL) return(FALSE);
//---
   m_sync.Lock();
   for(int i=0;i<m_quotes_total;i++)
     if(_stricmp(m_quotes[i].symbol,tick->symbol)==0)
       {
        memcpy(&m_quotes[i],tick,sizeof(SymbolTick));
        m_quotes[i].expiration+=ExtServer->TradeTime();
        m_sync.Unlock();
        return(TRUE);
       }
//---
   m_sync.Unlock();
   return(FALSE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CQuotesDispatcher::QuotesGet(LPCSTR symbol,SymbolTick *tick)
  {
//--- check parameters
   if(symbol==NULL || tick==NULL) return(FALSE);
//---
   m_sync.Lock();
   for(int i=0;i<m_quotes_total;i++)
     if(_stricmp(m_quotes[i].symbol,symbol)==0)
       {
        memcpy(tick,&m_quotes[i],sizeof(SymbolTick));
        m_sync.Unlock();
        return(TRUE);
       }
   m_sync.Unlock();
//---
   return(FALSE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CQuotesDispatcher::CheckPrice(RequestInfo *request,SymbolTick *tick)
  {
   int        res=FALSE;
//--- check parameters and prices
   if(request==NULL || tick==NULL)                               return(FALSE);
   if(request->trade.cmd!=OP_BUY && request->trade.cmd!=OP_SELL) return(FALSE);
   if(QuotesGet(request->trade.symbol,tick)==FALSE)              return(FALSE);
//---
   switch(request->trade.type)
     {
      case TT_ORDER_IE_OPEN:
      case TT_ORDER_REQ_OPEN:
        if(request->trade.cmd==OP_BUY)  res=request->trade.price>=tick->ask; // DB price better or equal client price
        else                            res=request->trade.price<=tick->bid; // DB price better or equal client price
        break;

      case TT_ORDER_IE_CLOSE:
      case TT_ORDER_REQ_CLOSE:
        if(request->trade.cmd==OP_SELL) res=request->trade.price>=tick->ask; // DB price better or equal client price
        else                            res=request->trade.price<=tick->bid; // DB price better or equal client price
        break;
     }
//--- show error
   if(res==FALSE)
      ExtLogger.Out(CmdErr,NULL,"'%d': request %s %.2lf %s at %.5lf (%.5lf / %.5lf) [old quotes]",
                 request->login,GetCmd(request->trade.cmd),request->trade.volume/100.0,
                 request->trade.symbol,request->trade.price,tick->bid,tick->ask);
//---
   return(res);
  }
//+------------------------------------------------------------------+
//| Check and correct StopLoss and Take Profit prices                |
//+------------------------------------------------------------------+
int CQuotesDispatcher::CorrectStopsPrice(TradeRecord *trade,SymbolTick *tick,const int isTP)
  {
   int         diff;
//--- check parameters and prices
   if(trade==NULL || tick==NULL)            return(FALSE);
   if(QuotesGet(trade->symbol,tick)==FALSE) return(FALSE);
//---
   if(isTP==TRUE) // Take Profit
     {
      if(trade->cmd==OP_BUY)
        {
         diff=(int)((tick->bid-trade->close_price)*GetDecimalPow(trade->digits));
         if(diff>ExtConfig.StopsTPSlippage()) trade->close_price=tick->bid;
        }
      else
        {
         diff=(int)((trade->close_price-tick->ask)*GetDecimalPow(trade->digits));
         if(diff>ExtConfig.StopsTPSlippage()) trade->close_price=tick->ask;
        }
     }
   else   // Stop Loss
     {
      if(trade->cmd==OP_BUY)
        {
         diff=(int)((trade->close_price-tick->bid)*GetDecimalPow(trade->digits));
         if(diff>ExtConfig.StopsSLSlippage()) trade->close_price=tick->bid;
        }
      else
        {
         diff=(int)((tick->ask-trade->close_price)*GetDecimalPow(trade->digits));
         if(diff>ExtConfig.StopsSLSlippage()) trade->close_price=tick->ask;
        }
     }
//--- show error
   if(diff<0)
     {
      ExtLogger.Out(CmdErr,NULL,"'%d': %s #%d %s %.2lf %s at %.5lf (%.5lf / %.5lf) [skipped]",
                    trade->login,isTP==TRUE ?"take profit":"stop loss",trade->order,
                    GetCmd(trade->cmd),trade->volume/100.0,
                    trade->symbol,trade->close_price,tick->bid,tick->ask);
      return(FALSE);
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Check and correct pending prices                                 |
//+------------------------------------------------------------------+
int CQuotesDispatcher::CorrectPendingsPrice(const TradeRecord *pending,TradeRecord *trade,SymbolTick *tick)
  {
   int         diff;
//--- check parameters and prices
   if(pending==NULL || trade==NULL || tick==NULL)  return(FALSE);
   if(QuotesGet(trade->symbol,tick)==FALSE)        return(FALSE);
//---
   switch(pending->cmd)
     {
      case OP_BUY_STOP:   // ut->open_price>ask
        diff=(int)((trade->open_price-tick->ask)*GetDecimalPow(trade->digits));
        if(diff>ExtConfig.PendingsSlippage()) trade->open_price=tick->ask;
        break;

      case OP_BUY_LIMIT:  // ut->open_price<ask
        diff=(int)((tick->ask-trade->open_price)*GetDecimalPow(trade->digits));
        if(diff>ExtConfig.PendingsSlippage()) trade->open_price=tick->ask;
        break;

      case OP_SELL_LIMIT: // ut->open_price>bid
        diff=(int)((trade->open_price-tick->bid)*GetDecimalPow(trade->digits));
        if(diff>ExtConfig.PendingsSlippage()) trade->open_price=tick->bid;
        break;

      case OP_SELL_STOP:  // ut->open_price<bid
        diff=(int)((tick->bid-trade->open_price)*GetDecimalPow(trade->digits));
        if(diff>ExtConfig.PendingsSlippage()) trade->open_price=tick->bid;
        break;
      default:
        return(FALSE);
     }
//--- show error
   if(diff<0)
     {
      ExtLogger.Out(CmdErr,NULL,"'%d': #%d %s %.2lf %s at %.5lf (%.5lf / %.5lf) [skipped]",
                    pending->login,pending->order,
                    GetCmd(pending->cmd),pending->volume/100.0,
                    pending->symbol,pending->close_price,tick->bid,tick->ask);
      return(FALSE);
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Check and correct stopout prices                                 |
//+------------------------------------------------------------------+
int CQuotesDispatcher::CorrectStopoutPrice(TradeRecord *trade,SymbolTick *tick)
  {
//--- check parameters and prices
   if(trade==NULL || tick==NULL)            return(FALSE);
   if(QuotesGet(trade->symbol,tick)==FALSE) return(FALSE);
//--- set market price
   trade->close_price=(trade->cmd==OP_BUY)?(tick->bid):(tick->ask);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

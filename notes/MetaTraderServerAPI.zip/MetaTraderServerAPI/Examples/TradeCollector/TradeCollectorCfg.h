//+------------------------------------------------------------------+
//|                                                   MT4 Connector  |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
#include "Configuration.h"
//+------------------------------------------------------------------+
//| Configuration file wrapper                                       |
//+------------------------------------------------------------------+
class CTradeCollectorCfg : public CConfiguration
  {
   char              m_trades_server[64];
   char              m_trades_login[64];
   char              m_trades_password[64];
   //---
   char              m_quotes_server[64];
   char              m_quotes_login[64];
   char              m_quotes_password[64];
   //---
   int               m_coverage_account;
   //---
   int               m_takeprofit_slippage;
   int               m_stoploss_slippage;
   int               m_pendings_slippage;

public:
                     CTradeCollectorCfg();
   virtual          ~CTradeCollectorCfg();
   virtual void      Reload();
   void              Initialize(const char *cfgname);
   //---
   LPCSTR            TradeServer()      { return(m_trades_server);   }
   LPCSTR            TradeLogin()       { return(m_trades_login);    }
   LPCSTR            TradePassword()    { return(m_trades_password); }
   //---
   LPCSTR            QuotesServer()     { return(m_quotes_server);   }
   LPCSTR            QuotesLogin()      { return(m_quotes_login);    }
   LPCSTR            QuotesPassword()   { return(m_quotes_password); }
   //---
   int               CoverageAccount()  { m_sync.Lock(); int tmp=m_coverage_account; m_sync.Unlock(); return(tmp); }
   //---
   int               StopsTPSlippage()  { m_sync.Lock(); int tmp=m_takeprofit_slippage; m_sync.Unlock(); return(tmp);    }
   int               StopsSLSlippage()  { m_sync.Lock(); int tmp=m_stoploss_slippage; m_sync.Unlock(); return(tmp);    }
   int               PendingsSlippage() { m_sync.Lock(); int tmp=m_pendings_slippage; m_sync.Unlock(); return(tmp);    }
  };
extern CTradeCollectorCfg ExtConfig;
//+------------------------------------------------------------------+

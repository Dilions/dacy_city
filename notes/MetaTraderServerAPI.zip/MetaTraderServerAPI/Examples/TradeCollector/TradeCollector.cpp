//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Logger.h"
#include "misc\common.h"
#include "QuotesDispatcher.h"
#include "TradeDispatcher.h"
#include "CoverageBase.h"
#include "TradeCollectorCfg.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#define             PLUGIN_DEALER    (7777777)
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
PluginInfo          ExtPluginInfo={ "Trade Collector",104,"MetaQuotes Software Corp.",{0} };
CServerInterface   *ExtServer=NULL;
UserInfo            ExtManagerInfo={0};
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
  {
   char *cp;
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
        //--- current folder
        GetModuleFileName((HMODULE)hModule,ExtProgramPath,sizeof(ExtProgramPath)-1);
        cp=&ExtProgramPath[strlen(ExtProgramPath)-2];
        while(cp>ExtProgramPath && *cp!='\\') cp--; *cp=0;
        //--- fill the manager structure
        ExtManagerInfo.login   =PLUGIN_DEALER;
        ExtManagerInfo.leverage=PLUGIN_TRADES_ID;
        COPY_STR(ExtManagerInfo.name,"Trade Collector API");
        COPY_STR(ExtManagerInfo.ip,"Trade Collector");
        //---
        ExtConfig.Initialize("TradeCollector.cfg");
        ExtLogger.Initialize("TradeCollector.log");
        //---
        ExtLogger.Out(CmdOK,NULL,"TradeCollector initialized");
        break;

      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
        break;

      case DLL_PROCESS_DETACH:
        ExtQuotesDispatcher.Shutdown();
        ExtTradesDispatcher.Shutdown();
        ExtCoverageBase.Save();
        break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL) return(FALSE);
   if(server->Version()!=ServerApiVersion)
     {
      ExtLogger.Out(CmdAtt,NULL,"Tick Collector: uncompatible MT Server API (version %d instead of %d)",server->Version(),ServerApiVersion);
      return(FALSE);
     }
//--- save server interface link
   ExtServer=server;
   ExtServer->LogsOut(CmdOK,"plugin","TickCollector: plugin initialized");
//--- start pumping quotes
   ExtQuotesDispatcher.Start();
   ExtTradesDispatcher.Start();
   ExtCoverageBase.Initialize();
//--- all is ok
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| MUST BE ALWAYS! CLEAR ALL OBJECTS HERE                           |
//+------------------------------------------------------------------+
void APIENTRY MtSrvCleanup(void)
  {
//---
   ExtQuotesDispatcher.Shutdown();
   ExtTradesDispatcher.Shutdown();
   ExtCoverageBase.Save();
//---
  }
//+------------------------------------------------------------------+
//| �������� ���������                                               |
//+------------------------------------------------------------------+
void APIENTRY MtSrvHistoryTickApply(const ConSymbol *symbol,FeedTick *inf)
  {
//   ExtLogger.Out("Tick: %s %.5lf / %.5lf",inf->symbol,inf->bid,inf->ask);
  }
//+------------------------------------------------------------------+
//| Incoming transactions                                            |
//+------------------------------------------------------------------+
void  APIENTRY MtSrvTradeRequestApply(RequestInfo *request,const int isdemo)
  {
   double      prices[2]={0};
   RequestInfo req;     // must be local copy of request
   SymbolTick  tick;
//--- check parameters
   if(request==NULL || isdemo!=FALSE || ExtServer==NULL) return;
//--- show request
   req=*request;
   ExtLogger.Out(CmdOK,NULL,"'%d': request %s %.2lf %s at %.5lf",
                 req.login,GetCmd(req.trade.cmd),req.trade.volume/100.0,
                 req.trade.symbol,req.trade.price);
//--- lets confirm the request
   switch(req.trade.type)
     {
      //--- Request Execution for prices
      case TT_PRICES_GET:
        ExtServer->HistoryPricesGroup(&req,prices);
        ExtServer->RequestsPrices(req.id,&ExtManagerInfo,prices,FALSE);
        break;

      //--- Request Execution for confirmations
      case TT_ORDER_REQ_OPEN:
      case TT_ORDER_REQ_CLOSE:
        if(ExtQuotesDispatcher.CheckPrice(&req,&tick)==TRUE)  // price is ok
          if(ExtTradesDispatcher.Process(&req,&tick)==TRUE)   // accepted by DB
            {
             req.internal_id=PLUGIN_TRADES_ID;
             ExtServer->RequestsConfirm(req.id,&ExtManagerInfo,prices); // confirm it
             break;
            }
          else
            {
             ExtServer->RequestsReset(req.id,&ExtManagerInfo,DC_RESETED);
             break;
            }
        //--- reset
        ExtServer->RequestsReset(req.id,&ExtManagerInfo,DC_RESETED);
        break;

      //--- Instant Execution Open/Close
      case TT_ORDER_IE_OPEN:
      case TT_ORDER_IE_CLOSE:
        if(ExtQuotesDispatcher.CheckPrice(&req,&tick)==TRUE)  // price is ok
          if(ExtTradesDispatcher.Process(&req,&tick)==TRUE)         // accepted by DB
            {
             req.internal_id=PLUGIN_TRADES_ID;
             ExtServer->RequestsConfirm(req.id,&ExtManagerInfo,prices); // confirm it
             break;
            }
          else
            {
             ExtServer->RequestsReset(req.id,&ExtManagerInfo,DC_RESETED);
             break;
            }
        //--- should we check IE deviation?
        if(req.trade.ie_deviation>0)
          {
           ConSymbol  symb;
           double     price=0;
           //--- take instrument settings
           ExtServer->SymbolsGet(req.trade.symbol,&symb);
           //--- request current prices, with spread difference
           ExtServer->HistoryPricesGroup(&req,prices);
           //--- find necessary price
           if(req.trade.type==TT_ORDER_IE_OPEN)
             price=(req.trade.cmd==OP_BUY)?(prices[1]):(prices[0]);
           else
             price=(req.trade.cmd==OP_BUY)?(prices[0]):(prices[1]);
           //--- calculate deviation
           double delta=GetDecimalPow(symb.digits)*fabs(NormalizeDouble(req.trade.price,symb.digits)-NormalizeDouble(price,symb.digits));
           delta=NormalizeDouble(delta,symb.digits);
           //--- is this price acceptable for client?
           if(delta<=req.trade.ie_deviation)
             {
              //--- set dealer's price
              request->trade.price=price;
              //--- try to send order to DB
              if(ExtQuotesDispatcher.CheckPrice(&req,&tick)==TRUE)  // price is ok
                if(ExtTradesDispatcher.Process(&req,&tick)==TRUE)   // accepted by DB
                  {
                   req.internal_id=PLUGIN_TRADES_ID;
                   ExtServer->RequestsConfirm(req.id,&ExtManagerInfo,prices); // confirm it
                   break;
                  }
             }
          }
        //--- drop client deviation and requote, server will use current bid/ask
        req.trade.ie_deviation=0;
        prices[0]=prices[1]=0;
        ExtServer->RequestsRequote(req.id,&ExtManagerInfo,prices,FALSE);
        break;

      //--- Market Execution
      case TT_ORDER_MK_OPEN:
      case TT_ORDER_MK_CLOSE:
        req.internal_id=PLUGIN_TRADES_ID;
        ExtServer->HistoryPricesGroup(&req,prices);
        ExtServer->RequestsConfirm(req.id,&ExtManagerInfo,prices);
        break;

      //---
      case TT_ORDER_PENDING_OPEN:
      case TT_ORDER_DELETE:
      case TT_ORDER_MODIFY:
      case TT_ORDER_CLOSE_BY:
      case TT_ORDER_CLOSE_ALL:
        ExtServer->RequestsConfirm(req.id,&ExtManagerInfo,prices);
        break;

      case TT_PRICES_REQUOTE:     // skip High Level requotes
        break;

      default:
        ExtLogger.Out(CmdAtt,NULL,"'%d': invalid request type %d",req.login,req.trade.type);
     }
//---
  }
//+------------------------------------------------------------------+
//| Stops intercepting                                               |
//+------------------------------------------------------------------+
int APIENTRY MtSrvTradeStopsFilter(const ConGroup *group,const ConSymbol *symbol,const TradeRecord *trade)
  {
//--- We process all stops by plugin
   return(RET_OK);
  }
//+------------------------------------------------------------------+
//| Stops processing                                                 |
//+------------------------------------------------------------------+
int APIENTRY MtSrvTradeStopsApply(const UserInfo *user,const ConGroup *group,const ConSymbol *sym,TradeRecord *trade,const int isTP)
  {
   RequestInfo req={0};
   SymbolTick  tick;
//--- check parameters
   if(user==NULL || group==NULL || trade==NULL || sym==NULL) return(RET_ERROR);
//--- notify
   ExtLogger.Out(CmdOK,NULL,"'%d': %s %s %.2lf %s at %.5lf",user->login,
                 (isTP==FALSE)? "stop loss":"take profit",
                 GetCmd(trade->cmd),trade->volume/100.0,trade->symbol,trade->close_price);
//--- check Close Price
   if(ExtQuotesDispatcher.CorrectStopsPrice(trade,&tick,isTP)==TRUE)    // price is ok
     {
      //--- fill the RequestInfo
      COPY_STR(req.group,user->group);
      COPY_STR(req.trade.symbol,trade->symbol);
      req.login       =trade->login;
      req.trade.type  =TT_ORDER_IE_CLOSE;
      req.trade.order =trade->order;
      req.trade.cmd   =trade->cmd;
      req.trade.volume=trade->volume;
      req.trade.price =trade->close_price;
      req.trade.sl    =trade->sl;
      req.trade.tp    =trade->tp;
      req.internal_id =PLUGIN_TRADES_ID;
      //--- process it
      if(ExtTradesDispatcher.Process(&req,&tick)==TRUE) return(RET_OK);  // accepted by DB
     }
//---
   return(RET_TRADE_OFFQUOTES);
  }
//+------------------------------------------------------------------+
//| Pendings intercepting                                            |
//+------------------------------------------------------------------+
int  APIENTRY MtSrvTradePendingsFilter(const ConGroup *group,const ConSymbol *symbol,const TradeRecord *trade)
  {
   return(RET_OK);
  }
//+------------------------------------------------------------------+
//| Pendings processing                                              |
//+------------------------------------------------------------------+
int  APIENTRY MtSrvTradePendingsApply(const UserInfo *user,const ConGroup *group,const ConSymbol *symbol,const TradeRecord *pending,TradeRecord *trade)
  {
   RequestInfo req={0};
   SymbolTick  tick;
//--- check parameters
   if(user==NULL || group==NULL || symbol==NULL || pending==NULL || trade==NULL) return(RET_ERROR);
//--- notify
   ExtLogger.Out(CmdOK,NULL,"'%d': activate %s %.2lf %s at %.5lf",user->login,
                 GetCmd(pending->cmd),pending->volume/100.0,pending->symbol,pending->open_price);
//--- check Open Price
   if(ExtQuotesDispatcher.CorrectPendingsPrice(pending,trade,&tick)==TRUE)    // price is ok
     {
      //--- fill the RequestInfo
      COPY_STR(req.group,user->group);
      COPY_STR(req.trade.symbol,trade->symbol);
      req.login       =trade->login;
      req.trade.type  =TT_ORDER_IE_OPEN;
      req.trade.order =trade->order;
      req.trade.cmd   =trade->cmd;
      req.trade.volume=trade->volume;
      req.trade.price =trade->open_price;
      req.trade.sl    =trade->sl;
      req.trade.tp    =trade->tp;
      req.internal_id =PLUGIN_TRADES_ID;
      //--- process it
      if(ExtTradesDispatcher.Process(&req,&tick)==TRUE) return(RET_OK);  // accepted by DB
     }
//---
   return(RET_TRADE_OFFQUOTES);
  }
//+------------------------------------------------------------------+
//| Stop-outs intercepting                                           |
//+------------------------------------------------------------------+
int  APIENTRY MtSrvTradeStopoutsFilter(const ConGroup *group,const ConSymbol *symbol,const int login,const double equity,const double margin)
  {
   return(RET_OK);
  }
//+------------------------------------------------------------------+
//| Stop-outs processing                                             |
//+------------------------------------------------------------------+
int  APIENTRY MtSrvTradeStopoutsApply(const UserInfo *user,const ConGroup *group,const ConSymbol *symbol,TradeRecord *stopout)
  {
   RequestInfo req={0};
   SymbolTick  tick;
//--- check parameters
   if(user==NULL || group==NULL || symbol==NULL || stopout==NULL) return(RET_ERROR);
//--- notify
   ExtLogger.Out(CmdOK,NULL,"'%d': stop-out #%d %s %.2lf %s",user->login,stopout->order,GetCmd(stopout->cmd),stopout->volume/100.0,stopout->symbol);
//--- check Open Price
   if(ExtQuotesDispatcher.CorrectStopoutPrice(stopout,&tick)==TRUE)    // price is ok
     {
      //--- fill the RequestInfo
      COPY_STR(req.group,user->group);
      COPY_STR(req.trade.symbol,stopout->symbol);
      req.login       =stopout->login;
      req.trade.type  =TT_ORDER_IE_CLOSE;
      req.trade.order =stopout->order;
      req.trade.cmd   =stopout->cmd;
      req.trade.volume=stopout->volume;
      req.trade.price =stopout->close_price;
      req.trade.sl    =stopout->sl;
      req.trade.tp    =stopout->tp;
      //--- process it
      if(ExtTradesDispatcher.Process(&req,&tick)==TRUE) return(RET_OK);  // accepted by DB
     }
//---
   return(RET_TRADE_OFFQUOTES);
  }
//+------------------------------------------------------------------+
//| Intercept low-level order reopening                              |
//+------------------------------------------------------------------+
void APIENTRY  MtSrvTradesAdd(TradeRecord *trade,const UserInfo *user,const ConSymbol *symb)
  {
   ExtCoverageBase.TradeAdd(trade,user,symb);
  }
//+------------------------------------------------------------------+
//| Intercept low-level order closing and modifieng                  |
//+------------------------------------------------------------------+
void APIENTRY  MtSrvTradesUpdate(TradeRecord *trade,UserInfo *user,const int mode)
  {
   ExtCoverageBase.TradeClose(trade,user,mode);
  }
//+------------------------------------------------------------------+
//| Plugin config access                                             |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgAdd(const PluginCfg *cfg)            { return ExtConfig.Add(cfg);             }
int APIENTRY MtSrvPluginCfgSet(const PluginCfg *values,const int total)
                                                                { return ExtConfig.Set(values,total);    }
int APIENTRY MtSrvPluginCfgGet(LPCSTR name,PluginCfg *cfg)      { return ExtConfig.Get(name,cfg);        }
int APIENTRY MtSrvPluginCfgNext(const int index,PluginCfg *cfg) { return ExtConfig.Next(index,cfg);      }
int APIENTRY MtSrvPluginCfgDelete(LPCSTR name)                  { return ExtConfig.Delete(name);         }
int APIENTRY MtSrvPluginCfgTotal()                              { return ExtConfig.Total();              }
int APIENTRY MtSrvPluginCfgLog(LPSTR log,const int max_len)     { return ExtLogger.Journal(log,max_len); }
//+------------------------------------------------------------------+

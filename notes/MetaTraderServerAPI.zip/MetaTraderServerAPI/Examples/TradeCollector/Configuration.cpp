//+------------------------------------------------------------------+
//|                                                   MT4 Connector  |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Configuration.h"
#include "Logger.h"
#include "Misc\Common.h"
//+------------------------------------------------------------------+
//| Config sorting by name                                           |
//+------------------------------------------------------------------+
int CConfiguration::SortByName(const void *left,const void *right)
  {
   PluginCfg *lft=(PluginCfg*)left,*rgh=(PluginCfg*)right;
   return strcmp(lft->name,rgh->name);
  }
//+------------------------------------------------------------------+
//| Search by name                                                   |
//+------------------------------------------------------------------+
int CConfiguration::SearchByName(const void *left,const void *right)
  {
   char      *lft=(char*)left;
   PluginCfg *rgh=(PluginCfg*)right;
   return strcmp(lft,rgh->name);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CConfiguration::CConfiguration() : m_cfg(NULL),m_cfg_total(0),m_cfg_max(0)
  {
   COPY_STR(m_cfgname,"config.ini");
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CConfiguration::~CConfiguration()
  {
   m_sync.Lock();
//---
   if(m_cfg!=NULL) { delete[] m_cfg; m_cfg=NULL; }
   m_cfg_total=m_cfg_max=0;
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Config reading function                                          |
//+------------------------------------------------------------------+
void CConfiguration::Load()
  {
   char       tmp[MAX_PATH],*cp,*start;
   FILE      *in;
   PluginCfg  cfg,*buf;
//---
   m_sync.Lock();
   _snprintf(tmp,sizeof(tmp)-1,"%s\\%s",ExtProgramPath,m_cfgname);
   if((in=fopen(tmp,"rt"))!=NULL)
     {
      while(fgets(tmp,sizeof(tmp)-1,in)!=NULL)
        {
         ClearLF(tmp);
         if(tmp[0]==';') continue;
         //--- skip spaces
         start=tmp; while(*start==' ') start++;
         if((cp=strchr(start,'='))==NULL) continue;
         //--- clean strcture
         ZeroMemory(&cfg,sizeof(cfg));
         //--- take config name
         *cp=0; COPY_STR(cfg.name,start);
         //--- skip spaces again
         cp++; while(*cp==' ') cp++;
         COPY_STR(cfg.value,cp);
         //--- check strings
         TERMINATE_STR(cfg.name);
         TERMINATE_STR(cfg.value);
         if(cfg.name[0]==0 || cfg.value[0]==0) continue;
         //--- add config
         if(m_cfg==NULL || m_cfg_total>=m_cfg_max) // check free space
           {
            if((buf=new PluginCfg[m_cfg_total+64])==NULL)
              {
               m_sync.Unlock();
               ExtLogger.Out(CmdErr,NULL,"Config: no enough memory");
               return;
              }
            //---
            if(m_cfg!=NULL)
              {
               if(m_cfg_total>0) memcpy(buf,m_cfg,sizeof(PluginCfg)*m_cfg_total);
               delete[] m_cfg;
              }
            m_cfg    =buf;
            m_cfg_max=m_cfg_total+64;
           }
         //--- ��������
         memcpy(&m_cfg[m_cfg_total++],&cfg,sizeof(PluginCfg));
        }
      fclose(in);
     }
//--- sort configs by name
   if(m_cfg_total>0) qsort(m_cfg,m_cfg_total,sizeof(PluginCfg),SortByName);
   m_sync.Unlock();
//--- buffer reload
   Reload();
  }
//+------------------------------------------------------------------+
//| Config saving                                                    |
//+------------------------------------------------------------------+
void CConfiguration::Save()
  {
   char  tmp[MAX_PATH];
   FILE *in;
//---
   m_sync.Lock();
   _snprintf(tmp,sizeof(tmp)-1,"%s\\%s",ExtProgramPath,m_cfgname);
   if((in=fopen(tmp,"wt"))!=NULL)
     {
      if(m_cfg!=NULL)
        for(int i=0;i<m_cfg_total;i++)
          fprintf(in,"%s=%s\n",m_cfg[i].name,m_cfg[i].value);
      fclose(in);
     }
   m_sync.Unlock();
//---
   Reload();
  }
//+------------------------------------------------------------------+
//| Adding\modification of the config                                |
//+------------------------------------------------------------------+
int CConfiguration::Add(const PluginCfg* cfg)
  {
   PluginCfg *config=NULL,*buf;
//--- check parameters
   if(cfg==NULL || cfg->name[0]==0) return(FALSE);
//---
   m_sync.Lock();
   if(m_cfg==NULL || (config=(PluginCfg*)bsearch(cfg,m_cfg,m_cfg_total,sizeof(PluginCfg),SortByName))==NULL)
     {
      if(m_cfg==NULL || m_cfg_total>=m_cfg_max)
        {
         if((buf=new PluginCfg[m_cfg_total+64])==NULL)
           {
            m_sync.Unlock();
            ExtLogger.Out(CmdErr,NULL,"Config: no enough memory");
            return(FALSE);
           }
         if(m_cfg!=NULL)
           {
            if(m_cfg_total>0) memcpy(buf,m_cfg,sizeof(PluginCfg)*m_cfg_total);
            delete[] m_cfg;
           }
         m_cfg    =buf;
         m_cfg_max=m_cfg_total+64;
        }
      memcpy(&m_cfg[m_cfg_total++],cfg,sizeof(PluginCfg));
      m_sync.Unlock();
      Reload();
      return(TRUE);
     }
   else
     if(config!=NULL) memcpy(config,cfg,sizeof(PluginCfg));
   m_sync.Unlock();
//---
   Save();
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Setting of full list of configs                                  |
//+------------------------------------------------------------------+
int CConfiguration::Set(const PluginCfg *values,const int total)
  {
   PluginCfg *buf;
//--- check parameters
   if(total<0) return(FALSE);
//---
   m_sync.Lock();
   if(values!=NULL && total>0)
     {
      //--- check free space
      if(m_cfg==NULL || total>=m_cfg_max)
        {
         if((buf=new PluginCfg[total+64])==NULL)
           {
            m_sync.Unlock();
            ExtLogger.Out(CmdErr,NULL,"Config: no enough memory");
            return(FALSE);
           }
         if(m_cfg!=NULL) delete[] m_cfg;
         //---
         m_cfg    =buf;
         m_cfg_max=total+64;
        }
      memcpy(m_cfg,values,sizeof(PluginCfg)*total);
     }
   m_cfg_total=total;
   m_sync.Unlock();
   Reload();
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Retrieving config by name                                        |
//+------------------------------------------------------------------+
int CConfiguration::Get(LPCSTR name,PluginCfg* cfg)
  {
   PluginCfg* config;
//--- ��������
   if(name==NULL || cfg==NULL) return(FALSE);
//---
   m_sync.Lock();
   if(m_cfg!=NULL)
     if((config=(PluginCfg*)bsearch(name,m_cfg,m_cfg_total,sizeof(PluginCfg),SearchByName))!=NULL)
       memcpy(cfg,config,sizeof(PluginCfg));
   m_sync.Unlock();
//---
   return(config!=NULL);
  }
//+------------------------------------------------------------------+
//| Retrieving config by index                                       |
//+------------------------------------------------------------------+
int CConfiguration::Next(const int index,PluginCfg* cfg)
  {
//--- ��������
   m_sync.Lock();
   if(cfg==NULL || m_cfg==NULL || index>=m_cfg_total) { m_sync.Unlock(); return(FALSE); }
   memcpy(cfg,&m_cfg[index],sizeof(PluginCfg));
   m_sync.Unlock();
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Deleting config                                                  |
//+------------------------------------------------------------------+
int CConfiguration::Delete(LPCSTR name)
  {
   PluginCfg* config;
//--- ��������
   if(name==NULL) return(FALSE);
//---
   m_sync.Lock();
   if(m_cfg!=NULL)
     if((config=(PluginCfg*)bsearch(name,m_cfg,m_cfg_total,sizeof(PluginCfg),SearchByName))!=NULL)
       {
        int index=config-m_cfg;
        if((index+1)<m_cfg_total) memmove(config,config+1,sizeof(PluginCfg)*(m_cfg_total-index-1));
        m_cfg_total--;
       }
   m_sync.Unlock();
//---
   return(config!=NULL);
  }
//+------------------------------------------------------------------+

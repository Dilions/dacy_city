//+------------------------------------------------------------------+
//|                                                       MetaTrader |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "CoverageBase.h"
#include "Logger.h"
#include "TradeCollectorCfg.h"
#include "Misc\Common.h"

CCoverageBase ExtCoverageBase;
extern CServerInterface   *ExtServer;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CCoverageBase::SortByOrder(const void *left,const void *right)
  {
   return((OrdersPair*)left)->order-((OrdersPair*)right)->order;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CCoverageBase::SearchByOrder(const void *left,const void *right)
  {
   return(*(int*)left)-((OrdersPair*)right)->order;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CCoverageBase::CCoverageBase() : m_orders(NULL),m_orders_total(0),m_orders_max(0)
  {
   ZeroMemory(&m_coverage,sizeof(m_coverage));
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CCoverageBase::~CCoverageBase()
  {
   Save();
//---
   m_sync.Lock();
   if(m_orders!=NULL) { delete[] m_orders; m_orders=NULL; }
   m_orders_total=m_orders_max=0;
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CCoverageBase::Initialize()
  {
   UserRecord user;
   char       tmp[256];
   FILE      *file;
   int        size;
//--- prepare
   m_sync.Lock();
   if(ExtServer->ClientsUserInfo(ExtConfig.CoverageAccount(),&user)==FALSE || ExtServer->GroupsGet(user.group,&m_coverage.grp)==FALSE)
     {
      m_sync.Unlock();
      ExtLogger.Out(CmdErr,NULL,"CoverageBase: invalid coverage account");
      return;
     }
//--- fill user info
   m_coverage.login                 =user.login;
   m_coverage.enable                =user.enable;
   m_coverage.enable_change_password=user.enable_change_password;
   m_coverage.enable_read_only      =user.enable_read_only;
   m_coverage.leverage              =user.leverage;
   m_coverage.agent_account         =user.agent_account;
   m_coverage.credit                =user.credit;
   m_coverage.balance               =user.balance;
   m_coverage.prevbalance           =user.prevbalance;
   COPY_STR(m_coverage.group,user.group);
   COPY_STR(m_coverage.name,user.name);
//--- read base
   _snprintf(tmp,sizeof(tmp)-1,"%s\\TradeCollectorCoverage.dat",ExtProgramPath);
   if((file=fopen(tmp,"rb"))!=NULL)
     {
      //--- read version
      if(fread(&size,sizeof(size),1,file)!=1)
        {
         m_sync.Unlock();
         ExtLogger.Out(CmdErr,NULL,"CoverageBase: version reading error");
         return;
        }
      //--- calculate size
      if((size=(_filelength(_fileno(file))-sizeof(int))/sizeof(OrdersPair))<1) { m_sync.Unlock(); return; }
      //--- allocate memory
      if(m_orders==NULL || size>=m_orders_max)
        {
         OrdersPair *orders=new OrdersPair[size+512];
         if(orders==NULL)
           {
            m_sync.Unlock();
            ExtLogger.Out(CmdErr,NULL,"CoverageBase: no enoug memory");
            return;
           }
         if(m_orders!=NULL) delete[] m_orders;
         m_orders    =orders;
         m_orders_max=size+512;
        }
      //---
      if(fread(m_orders,sizeof(OrdersPair)*size,1,file)!=1)
        {
         m_sync.Unlock();
         ExtLogger.Out(CmdErr,NULL,"CoverageBase: base reading error");
         return;
        }
      m_orders_total=size;
      //--- sort
      if(m_orders_total>1)  qsort(m_orders, m_orders_total, sizeof(OrdersPair),SortByOrder);
     }
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Right coverage base on disk                                      |
//+------------------------------------------------------------------+
void CCoverageBase::Save()
  {
   FILE *file;
   int   version=PLUGIN_BASE_VERSION;
   char  tmp[256];
//--- prepare
   m_sync.Lock();
//--- read base
   if(m_orders_total>0 && m_orders!=NULL)
     {
      _snprintf(tmp,sizeof(tmp)-1,"%s\\TradeCollectorCoverage.dat",ExtProgramPath);
      if((file=fopen(tmp,"wb"))!=NULL)
        {
         if(fwrite(&version,sizeof(version),1,file)!=1 || fwrite(m_orders,sizeof(OrdersPair)*m_orders_total,1,file)!=1)
           {
            fclose(file);
            m_sync.Unlock();
            ExtLogger.Out(CmdErr,NULL,"CoverageBase: base writing error");
           }
         fclose(file);
        }
     }
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Check and add hedging order                                      |
//+------------------------------------------------------------------+
void CCoverageBase::TradeAdd(TradeRecord *trade,const UserInfo *user,const ConSymbol *symb)
  {
   TradeRecord  mirror_trade={0};
   int          coverage_order;
   DWORD        thread_id;
//--- check parameters
   if(trade==NULL || user==NULL || symb==NULL || ExtServer==NULL) return;
//--- process only BUY and SELL trades
   if(trade->cmd!=OP_BUY && trade->cmd!=OP_SELL) return;
//--- process only trades processed by Bank Emulator
   if(trade->internal_id!=PLUGIN_TRADES_ID) return;
//--- check if this is cyclic hook
   if((thread_id=GetCurrentThreadId())==trade->magic)  return;
   m_sync.Lock();
//--- fill order
   memcpy(&mirror_trade,trade,sizeof(TradeRecord));
   mirror_trade.order =0;
   mirror_trade.login =ExtConfig.CoverageAccount();
   mirror_trade.sl    =0;
   mirror_trade.tp    =0;
   mirror_trade.profit=0;
   mirror_trade.magic =thread_id;
//--- save mirror order in trade's internal_id
   _snprintf(mirror_trade.comment,sizeof(mirror_trade.comment)-1,"coverage for #%d",trade->order);
   if((coverage_order=ExtServer->OrdersAdd(&mirror_trade,&m_coverage,symb))>0)
     if(TradeCacheAdd(trade->order,coverage_order)==FALSE)
       {
        //--- delete hedged trade
        mirror_trade.order=coverage_order;
        ExtServer->OrdersUpdate(&mirror_trade,&m_coverage,UPDATE_DELETE);
        ExtLogger.Out(CmdErr,NULL,"CoverageBase: cache inserting error for #%d, order #%d deleted",trade->order,mirror_trade.order);
        //---
        m_sync.Unlock();
        return;
       }
   m_sync.Unlock();
//--- report results
   ExtLogger.Out(CmdOK,NULL,"CoverageBase: open #%d on '%d' for #%d on '%d'",coverage_order,m_coverage.login,trade->order,trade->login);
  }
//+------------------------------------------------------------------+
//| Find hedged order and close it                                   |
//+------------------------------------------------------------------+
void CCoverageBase::TradeClose(TradeRecord *trade,UserInfo *user,const int mode)
  {
   DWORD        thread_id;
   OrdersPair  *pair;
   TradeRecord  hedge_trade={0};
//--- check parameters
   if(trade==NULL || user==NULL || ExtServer==NULL) return;
//--- we don't need usual modification
   if(mode==UPDATE_NORMAL) return;
//--- process only BUY and SELL trades
   if(trade->cmd!=OP_BUY && trade->cmd!=OP_SELL) return;
//--- check if this is cyclic hook
   if((thread_id=GetCurrentThreadId())==trade->magic)  return;
//--- this is activation of opened order?
   if(mode==UPDATE_ACTIVATE)
     {
      ConSymbol sec={0};
      ExtServer->SymbolsGet(trade->symbol,&sec);
      TradeAdd(trade,user,&sec);
      return;
     }
//---
   m_sync.Lock();
//--- find info...
   if(m_orders!=NULL && (pair=(OrdersPair*)bsearch(&trade->order,m_orders,m_orders_total,sizeof(OrdersPair),SearchByOrder))!=NULL)
     {
      //--- find order
      if(ExtServer->OrdersGet(pair->coverage_order,&hedge_trade)!=FALSE || strcmp(trade->symbol,hedge_trade.symbol)!=0)
        {
         //--- prepare hedge trade
         hedge_trade.volume     =trade->volume;
         hedge_trade.close_time =trade->close_time;
         hedge_trade.close_price=trade->close_price;
         hedge_trade.magic      =thread_id;
         //--- calc order profit
         if(mode==UPDATE_CLOSE) ExtServer->TradesCalcProfit(m_coverage.group,&hedge_trade);
         else
           {
            hedge_trade.profit=0;
            hedge_trade.commission=0;
            hedge_trade.storage=0;
           }
         //--- close hedged order
         if(ExtServer->OrdersUpdate(&hedge_trade,&m_coverage,mode)==FALSE)
           ExtLogger.Out(CmdErr,NULL,"CoverageBase: coverage order #%d closing error",pair->coverage_order,pair->order);
         else
           {
            ExtLogger.Out(CmdOK,NULL,"CoverageBase: coverage order #%d on '%d' for #%d on '%d' closed",pair->coverage_order,hedge_trade.login,
                                                                                         pair->order,trade->login);
           }
        }
      else ExtLogger.Out(CmdErr,NULL,"CoverageBase: coverage order #%d finding error for #%d [server]",pair->coverage_order,pair->order);
      //--- remove pair from buffer
      TradeCacheRemove(pair);
     }
   else ExtLogger.Out(CmdErr,NULL,"CoverageBase: no coverage order for #%d",trade->order);
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Adding information into base                                     |
//+------------------------------------------------------------------+
int CCoverageBase::TradeCacheAdd(const int order,const int coverage_order)
  {
   OrdersPair  *newbuf,pair;
//--- check memory
   if(m_orders_total>=m_orders_max || m_orders==NULL)
     {
      if((newbuf=new OrdersPair[m_orders_total+512])==NULL)
        {
         m_sync.Unlock();
         return(FALSE);
        }
      if(m_orders!=NULL)
        {
         if(m_orders_total>0) memcpy(newbuf,m_orders,sizeof(OrdersPair)*m_orders_total);
         delete[] m_orders;
        }
      m_orders    =newbuf;
      m_orders_max=m_orders_total+512;
     }
//--- add hedged pair
   pair.order         =order;
   pair.coverage_order=coverage_order;
   if(insert(m_orders,&pair,m_orders_total,sizeof(OrdersPair),SortByOrder)==NULL)
     return(FALSE);
//---
   m_orders_total++;
   Save();
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Deleting pair from base                                          |
//+------------------------------------------------------------------+
void CCoverageBase::TradeCacheRemove(OrdersPair* pair)
  {
//--- check
   if(pair==NULL) return;
//---
   int index=pair-m_orders;
   if((index+1)<m_orders_total) memmove(pair,pair+1,sizeof(OrdersPair)*(m_orders_total-index-1));
   m_orders_total--;
   Save();
//---
   return;
  }
//+------------------------------------------------------------------+

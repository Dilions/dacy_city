//+------------------------------------------------------------------+
//|                                                  Trade Collector |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Logger.h"
#include "misc\common.h"
#include "tradedispatcher.h"
#include "quotesdispatcher.h"

CTradeDispatcher ExtTradesDispatcher;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CTradeDispatcher::CTradeDispatcher(void) : m_trades_total(0),m_thread(NULL),m_finished(FALSE),m_requests_total(0)
  {
//---
   ZeroMemory(m_trades,sizeof(m_trades));
   ZeroMemory(&m_cfg,sizeof(m_cfg));
   ZeroMemory(m_requests,sizeof(m_requests));
//---
   COPY_STR(m_cfg.server,"localhost:4444");
   COPY_STR(m_cfg.login,"TRADES");
   COPY_STR(m_cfg.password,"PASSWORD");
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CTradeDispatcher::~CTradeDispatcher(void)
  {
   Shutdown();
//---
   m_sync.Lock();
//---
   for(int i=0;i<m_requests_total;i++)
     if(m_requests[i].complete_event!=NULL)
       {
        CloseHandle(m_requests[i].complete_event);
        m_requests[i].complete_event=NULL;
       }
//---
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Read configuration                                               |
//+------------------------------------------------------------------+
void CTradeDispatcher::Initialize(void)
  {
   char  tmp[256],*cp;
   FILE *in;
//--- construct config filename
   GetModuleFileName(NULL,tmp,sizeof(tmp)-1);
   if((cp=strrchr(tmp, '.'))!=NULL) *cp=0;
   strcat(tmp,".cfg");
//--- open file and read all lines
   m_sync.Lock();
   if((in=fopen(tmp,"rt"))!=NULL)
     {
      while(fgets(tmp,250,in)!=NULL)
        {
         ClearLF(tmp);
         if(tmp[0]==';') continue;
         //--- parse lines
         if(GetStrParam(tmp,"ServerTrades="  ,m_cfg.server  ,sizeof(m_cfg.server)-1)  ==TRUE) continue;
         if(GetStrParam(tmp,"LoginTrades="   ,m_cfg.login   ,sizeof(m_cfg.login)-1)   ==TRUE) continue;
         if(GetStrParam(tmp,"PasswordTrades=",m_cfg.password,sizeof(m_cfg.password)-1)==TRUE) continue;
        }
      fclose(in);
     }
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Start pumping thread                                             |
//+------------------------------------------------------------------+
void CTradeDispatcher::Start(void)
  {
   DWORD     ret;
   UINT      id=0;
//---
   Initialize();
   m_sync.Lock();
//--- check thread
   if(m_thread!=NULL)
     {
      GetExitCodeThread(m_thread,&ret);
      if(ret!=STILL_ACTIVE) { CloseHandle(m_thread); m_thread=NULL; }
     }
//--- start thread
   if(m_thread==NULL)
     m_thread=(HANDLE)_beginthreadex(NULL,256000,ThreadProc,(void*)this,0,&id);
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Shutdown pumping thread                                          |
//+------------------------------------------------------------------+
void CTradeDispatcher::Shutdown(void)
  {
//--- close socket
   m_sync.Lock();
   m_socket.SendString("LOGOUT\r\n",8);
   m_finished=TRUE;
   m_socket.Close();
   m_sync.Unlock();
//--- terminate thread
   if(m_thread!=NULL)
     {
      WaitForSingleObject(m_thread,INFINITE);
      CloseHandle(m_thread);
      m_thread=NULL;
     }
//---
  }
//+------------------------------------------------------------------+
//| Thread entry point                                               |
//+------------------------------------------------------------------+
UINT __stdcall CTradeDispatcher::ThreadProc(LPVOID lParam)
  {
//---
   CTradeDispatcher *pThis=reinterpret_cast<CTradeDispatcher*>(lParam);
   if(pThis!=NULL) pThis->PumpThread();
//---
   return(0);
  }
//+------------------------------------------------------------------+
//| Quotes pumping thread                                            |
//+------------------------------------------------------------------+
void CTradeDispatcher::PumpThread(void)
  {
   char     tmp[256];
//--- loop until finished
   while(m_finished==FALSE)
     {
      //--- connect
      if(m_socket.Connect(m_cfg.server)==FALSE)
        {
         ExtLogger.Out(CmdErr,NULL,"Trades: connection error %s",m_cfg.server);
         Sleep(1000);
         continue;
        }
      //--- switch to quotes
      _snprintf(tmp,sizeof(tmp)-1,"LOGIN %s %s\n",m_cfg.login,m_cfg.password);
      if(m_socket.SendString(tmp,0)==FALSE)
        {
         m_socket.Close();
         ExtLogger.Out(CmdErr,NULL,"Trades: switch error");
         Sleep(1000);
         continue;
        }
      //--- read quotes
      while(m_finished==FALSE)
        {
         if(m_socket.ReadString(tmp,sizeof(tmp)-1)<0)
           {
            m_socket.Close();
            ExtLogger.Out(CmdErr,NULL,"Trades: read error");
            Sleep(1000);
            break;
           }

         //---
         if(memcmp(tmp,"REPLY",5)==0) RequestReply(tmp+5);
         if(memcmp(tmp,"EOF",3)==0)   RequestFree();
         if(memcmp(tmp,"ERROR",5)==0) ExtLogger.Out(CmdErr,NULL,"Trades: DB error - %s",tmp+1);
        }
      m_socket.SendString("LOGOUT\r\n",8);
      m_socket.Close();
     }
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CTradeDispatcher::Process(RequestInfo *request,SymbolTick *tick)
  {
   char          tmp[256],*cmd;
   double        dbprice;
   TradeRequest *trade;
   HANDLE        event;
   int           i,result;
   tm           *ttm;
//---
   if(request==NULL) return(FALSE);
//--- swap type of operation for CLOSE transactions
   if(request->trade.type==TT_ORDER_REQ_CLOSE ||
      request->trade.type==TT_ORDER_IE_CLOSE  ||
      request->trade.type==TT_ORDER_MK_CLOSE) request->trade.cmd=(request->trade.cmd==OP_BUY ? OP_SELL:OP_BUY);
//---
   m_sync.Lock();
//--- add new request
   if((trade=RequestFindFree())==NULL)
     {
      ExtLogger.Out(CmdErr,NULL,"Trades: no enough free space for request");
      m_sync.Unlock();
      return(FALSE);
     }
//--- fill request
   trade->request_id=request->id;
   trade->result    =FALSE;
   trade->status    =REQ_REQUEST;
   if(trade->complete_event==NULL)
     {
      if((trade->complete_event=CreateEvent(NULL,FALSE,FALSE,NULL))==NULL)
        {
         ExtLogger.Out(CmdErr,NULL,"Trades: event creation error");
         m_sync.Unlock();
         return(FALSE);
        }
     }
   else ResetEvent(trade->complete_event);
//---
   event=trade->complete_event;
//--- fill the record
   if(request->trade.cmd==OP_BUY) { cmd="BUY";  dbprice=tick->ask; }
   else                           { cmd="SELL"; dbprice=tick->bid; }
//---
   ttm=gmtime(&tick->value_date);
   _snprintf(tmp,sizeof(tmp)-1,"TRADE %d, %d, %s, %.2lf, %s, %.5lf, %.5lf, %04d-%02d-%02d, %s\r\n",
             request->id,request->login,cmd,request->trade.volume/100.0,
             request->trade.symbol,request->trade.price,dbprice,ttm->tm_year+1900,ttm->tm_mon+1,ttm->tm_mday,tick->rate_id);
//--- send it
   m_socket.SendString(tmp,strlen(tmp));
   m_sync.Unlock();
//--- wait result
   if(WaitForSingleObject(event,MAX_WAIT_TIME)!=WAIT_OBJECT_0)
     {
      ExtLogger.Out(CmdErr,NULL,"Trades: '%d' no answer [timeout] in queue",request->login);
      return(FALSE);
     }
//--- ok, find result
   m_sync.Lock();
   for(i=0;i<m_requests_total;i++)
     if(m_requests[i].request_id==request->id)
       {
        result=m_requests[i].result;
        m_requests[i].status=REQ_EMPTY;
        m_sync.Unlock();
        return(result);
       }
   m_sync.Unlock();
//--- we didn't find anything-error!
   return(FALSE);
  }
//+------------------------------------------------------------------+
//| DB trade reply parser
//| REPLY id,login,cmd,volume,symbol,price,bid/ask,rate-id,status,message |
//+------------------------------------------------------------------+
void CTradeDispatcher::RequestReply(char* str)
  {
   int    i,request_id=0,result=FALSE;
   char  *cp,*ep,*comment;
//---
   if(str==NULL) return;
//--- trade ID
   if((cp=strchr(str,','))==NULL)  return;
   *cp=0;
   request_id=atol(str);
//--- find status...
   if((ep=strchr(cp+1,','))==NULL)  return; // login
   if((cp=strchr(ep+1,','))==NULL)  return; // cmd
   if((ep=strchr(cp+1,','))==NULL)  return; // volume
   if((cp=strchr(ep+1,','))==NULL)  return; // sym
   if((ep=strchr(cp+1,','))==NULL)  return; // price
   if((cp=strchr(ep+1,','))==NULL)  return; // bid/ask
   if((ep=strchr(cp+1,','))==NULL)  return; // rate-id
//--- parse result
   if((cp=strchr(ep+1,','))==NULL)   return; // status
   *cp=0;
   result=(strcmp(ep+2,"OK")==0);
//--- parse message\comment
   comment=cp+2;
//--- find request
   m_sync.Lock();
   for(i=0;i<m_requests_total;i++)
     if(m_requests[i].status==REQ_REQUEST)
       if(m_requests[i].request_id==request_id)
         {
          m_requests[i].result=result;
          if(m_requests[i].complete_event!=NULL) SetEvent(m_requests[i].complete_event);
          m_sync.Unlock();
          return;
         }
   m_sync.Unlock();
//---
   ExtLogger.Out(CmdErr,NULL,"Trades: unknown replay");
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CTradeDispatcher::RequestFree()
  {
//---
   m_sync.Lock();
//---
   for(int i=0;i<m_requests_total;i++)
     {
      m_requests[i].result=FALSE;
      m_requests[i].status=REQ_EMPTY;
      if(m_requests[i].complete_event!=NULL) ResetEvent(m_requests[i].complete_event);
     }
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
TradeRequest* CTradeDispatcher::RequestFindFree()
  {
//--- find free request
   for(int i=0;i<m_requests_total;i++)
     if(m_requests[i].status==REQ_EMPTY) return(&m_requests[i]);
//--- can we add new one?
   if(m_trades_total<MAX_REQUEST) return(&m_requests[m_requests_total++]);
//---
   return(NULL);
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Processor.h"
//---  server interface
extern CServerInterface *ExtServer;
//--- processor
CProcessor               ExtProcessor;
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CProcessor::CProcessor() :
               m_pend_set_allow(FALSE),          m_pend_set_minpips(20),
               m_pend_mod_allow(FALSE),          m_pend_mod_minpips(20),
               m_pend_del_allow(FALSE),          m_pend_del_minpips(20),
               m_order_mod_allow(FALSE),         m_order_mod_pips(20),
               m_order_close_loss_allow(FALSE),  m_order_close_loss_minpips(20),
               m_order_close_profit_allow(FALSE),m_order_close_profit_minpips(20),
               m_order_closeby_allow(FALSE),     m_order_multcloseby_allow(FALSE),
               m_reinitialize_flag(0),m_requests_total(0), m_requests_processed(0),
               m_volatiles(NULL),     m_volatiles_total(0),m_volatiles_max(0)
  {
//--- fill user info
   ZeroMemory(&m_manager,sizeof(m_manager));
   m_manager.login=55555;
   COPY_STR(m_manager.name,"Dealer Helper");
   COPY_STR(m_manager.ip,  "DealerHelper");
   COPY_STR(m_symbols,     "*");
//---
  }
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CProcessor::~CProcessor()
  {
//--- delete symbols
   m_sync.Lock();
   if(m_volatiles!=NULL) { delete []m_volatiles; m_volatiles=NULL; }
   m_volatiles_total=m_volatiles_max=0;
   m_sync.Unlock();
//---
  }
//+------------------------------------------------------------------+
//| Reading of config file                                           |
//+------------------------------------------------------------------+
void CProcessor::Initialize()
  {
//---
   ExtConfig.GetInteger("Order CloseLoss Allow",        &m_order_close_loss_allow,     "0");
   ExtConfig.GetInteger("Order CloseLoss MinPips",      &m_order_close_loss_minpips,  "20");

   ExtConfig.GetInteger("Order CloseProfit Allow",      &m_order_close_profit_allow,   "0");
   ExtConfig.GetInteger("Order CloseProfit MinPips",    &m_order_close_profit_minpips,"20");

   ExtConfig.GetInteger("Order CloseBy Allow",          &m_order_closeby_allow,        "0");
   ExtConfig.GetInteger("Order Multiple CloseBy Allow", &m_order_multcloseby_allow,    "0");

   ExtConfig.GetInteger("Order Modify Allow",           &m_order_mod_allow,            "0");
   ExtConfig.GetInteger("Order Modify MinPips",         &m_order_mod_pips,            "20");

   ExtConfig.GetInteger("Pending Delete Allow",         &m_pend_del_allow,             "0");
   ExtConfig.GetInteger("Pending Delete MinPips",       &m_pend_del_minpips,          "20");

   ExtConfig.GetInteger("Pending Modify Allow",         &m_pend_mod_allow,             "0");
   ExtConfig.GetInteger("Pending Modify MinPips",       &m_pend_mod_minpips,          "20");

   ExtConfig.GetInteger("Pending Set Allow",            &m_pend_set_allow,             "0");
   ExtConfig.GetInteger("Pending Set MinPips",          &m_pend_set_minpips,          "20");
//--- receive symbols
   ExtConfig.GetString("Symbols",m_symbols,sizeof(m_symbols)-1,"*");
   if(m_symbols[0]==0) COPY_STR(m_symbols,"*");
//--- notify
   Out(CmdOK,"DealerHelper","'%d': initialized as virtual dealer",m_manager.login);
  }
//+------------------------------------------------------------------+
//| Show statistics                                                  |
//+------------------------------------------------------------------+
void CProcessor::ShowStatus()
  {
   char tmp[256];
//---
   if(ExtServer!=NULL && m_requests_total>0)
     {
      //--- this line is used by the Log Analyser in order to calculate the requests
      //--- processed by the Helper, this is why it is not recommended to modify it
      _snprintf(tmp,sizeof(tmp)-1,"'%d': %d of %d requests processed (%.2lf%%)",
               m_manager.login,m_requests_processed,m_requests_total,m_requests_processed*100.0/m_requests_total);
      ExtServer->LogsOut(CmdOK,"DealerHelper",tmp);
     }
//---
  }
//+------------------------------------------------------------------+
//| Request processing                                               |
//+------------------------------------------------------------------+
void CProcessor::ProcessRequest(RequestInfo *request)
  {
   double           prices[2]={0},delta;
   int              profit;
   TradeRecord      trade;
   ConSymbol        symbol;
   TradeTransInfo  *trans=&request->trade;
//--- check
   if(ExtServer==NULL) return;
//--- increase counter
   m_requests_total++;
//--- reinitialize if configuration changed
   if(InterlockedExchange(&m_reinitialize_flag,0)!=0) Initialize();
//--- lets confirm the request
   switch(trans->type)
     {
      //--- check pending opening
      case TT_ORDER_PENDING_OPEN:
         if(m_pend_set_allow!=FALSE && CheckGroup(m_symbols,trans->symbol)!=FALSE)
            if(ExtServer->HistoryPricesGroup(request,prices)==RET_OK &&
               ExtServer->SymbolsGet(trans->symbol,&symbol) !=FALSE)
              {
               //--- check whether the symbol is allowed to be 
               if(CheckVolatile(trans->symbol)==FALSE) break;
               //--- calc prices deviation
               delta=NormalizeDouble(symbol.point*m_pend_set_minpips,symbol.digits);
               switch(trans->cmd)
                 {
                  case OP_BUY_LIMIT:
                     if(trans->price>(prices[1]-delta)) return;
                     break;
                  case OP_SELL_LIMIT:
                     if(trans->price<(prices[0]+delta)) return;
                     break;
                  case OP_BUY_STOP:
                     if(trans->price<(prices[1]+delta)) return;
                     break;
                  case OP_SELL_STOP:
                     if(trans->price>(prices[0]-delta)) return;
                     break;
                  default:
                     return;
                 }
               //--- confirm
               ExtServer->RequestsConfirm(request->id,&m_manager,prices);
               m_requests_processed++;
              }
         break;
         //--- check pending deleting
      case TT_ORDER_DELETE:
         if(m_pend_del_allow!=FALSE && CheckGroup(m_symbols,trans->symbol)!=FALSE)
            if(ExtServer->SymbolsGet(trans->symbol,&symbol)!=FALSE && ExtServer->OrdersGet(trans->order,&trade)!=FALSE)
              {
               //--- calc prices deviation
               delta=NormalizeDouble(symbol.point*m_pend_del_minpips,symbol.digits);
               switch(trans->cmd)
                 {
                  case OP_BUY_LIMIT:
                     if(trade.open_price>(trade.close_price-delta)) return;
                     break;
                  case OP_SELL_LIMIT:
                     if(trade.open_price<(trade.close_price+delta)) return;
                     break;
                  case OP_BUY_STOP:
                     if(trade.open_price<(trade.close_price+delta)) return;
                     break;
                  case OP_SELL_STOP:
                     if(trade.open_price>(trade.close_price-delta)) return;
                     break;
                  default:
                     return;
                 }
               //--- confirm
               ExtServer->RequestsConfirm(request->id,&m_manager,prices);
               m_requests_processed++;
              }
         break;
         //--- check pending deleting
      case TT_ORDER_MODIFY:
         if(CheckGroup(m_symbols,trans->symbol)==FALSE ||
            ExtServer->OrdersGet(trans->order,&trade)==FALSE) return;
         //--- this is pending?
         if(trade.cmd>OP_SELL && m_pend_mod_allow!=FALSE)
            if(ExtServer->SymbolsGet(trans->symbol,&symbol)!=FALSE)
              {
               //--- check whether the symbol is allowed to be 
               if(CheckVolatile(trans->symbol)==FALSE) break;
               //--- calc prices deviation
               delta=NormalizeDouble(symbol.point*m_pend_mod_minpips,symbol.digits);
               switch(trans->cmd)
                 {
                  case OP_BUY_LIMIT:
                     if(trade.open_price>(trade.close_price-delta)) return;
                     break;
                  case OP_SELL_LIMIT:
                     if(trade.open_price<(trade.close_price+delta)) return;
                     break;
                  case OP_BUY_STOP:
                     if(trade.open_price<(trade.close_price+delta)) return;
                     break;
                  case OP_SELL_STOP:
                     if(trade.open_price>(trade.close_price-delta)) return;
                     break;
                  default:
                     return;
                 }
               //--- confirm
               ExtServer->RequestsConfirm(request->id,&m_manager,prices);
               m_requests_processed++;
              }
         //--- this is order?
         if(trade.cmd<=OP_SELL && m_order_mod_allow!=FALSE)
            if(ExtServer->SymbolsGet(trans->symbol,&symbol)!=FALSE)
              {
               //--- check whether the symbol is allowed to be 
               if(CheckVolatile(trans->symbol)==FALSE) break;
               //--- calc delta
               delta=NormalizeDouble(symbol.point*m_order_mod_pips,symbol.digits);
               //--- take-profit
               if(trans->tp>0 && trade.tp!=trans->tp)
                 {
                  if(trade.cmd==OP_BUY  && trans->tp<(trade.close_price+delta)) return;
                  if(trade.cmd==OP_SELL && trans->tp>(trade.close_price-delta)) return;
                 }
               //--- stop-loss
               if(trans->sl>0 && trade.sl!=trans->sl)
                 {
                  if(trade.cmd==OP_BUY  && trans->sl>(trade.close_price-delta)) return;
                  if(trade.cmd==OP_SELL && trans->sl<(trade.close_price+delta)) return;
                 }
               //--- confirm
               ExtServer->RequestsConfirm(request->id,&m_manager,prices);
               m_requests_processed++;
              }
         break;
         //--- check order closing
      case TT_ORDER_IE_CLOSE:
         if((m_order_close_loss_allow!=FALSE || m_order_close_profit_allow!=FALSE) && CheckGroup(m_symbols,trans->symbol)!=FALSE)
            if(ExtServer->OrdersGet(trans->order,&trade)!=FALSE)
              {
               //--- check whether the symbol is allowed to be 
               if(CheckVolatile(trans->symbol)==FALSE) break;
               //---
               if(trans->cmd==OP_BUY) profit=(int)(DecPow(trade.digits)*NormalizeDouble(trade.close_price-trade.open_price,trade.digits));
               else                   profit=(int)(DecPow(trade.digits)*NormalizeDouble(trade.open_price-trade.close_price,trade.digits));
               //--- check
               if((m_order_close_loss_allow!=FALSE   && -profit>=m_order_close_loss_minpips) ||
                  (m_order_close_profit_allow!=FALSE &&  profit>=m_order_close_profit_minpips))
                 {
                  ExtServer->RequestsConfirm(request->id,&m_manager,prices);
                  m_requests_processed++;
                 }
              }
         break;
         //--- close by processing
      case TT_ORDER_CLOSE_BY:
         if(m_order_closeby_allow!=FALSE)
           {
            ExtServer->RequestsConfirm(request->id,&m_manager,prices);
            m_requests_processed++;
           }
         break;
         //--- multiple close by processing
      case TT_ORDER_CLOSE_ALL:
         if(m_order_multcloseby_allow!=FALSE)
           {
            ExtServer->RequestsConfirm(request->id,&m_manager,prices);
            m_requests_processed++;
           }
         break;
     }
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CProcessor::TickApply(const ConSymbol *symbol,FeedTick *inf)
  {
   int             i,j;
   SymbolVolatile *sv,*temp;
   double          sma,current,spread;
//--- checking
   if(symbol==NULL || inf==NULL || symbol->trade==TRADE_NO) return;
//---
   m_sync.Lock();
//--- are any symbols available?
   if(m_volatiles==NULL)
     {
      //--- allocate memory for this issue
      if((m_volatiles=new SymbolVolatile[1024])==NULL) { m_sync.Unlock(); return; }
      //--- set 
      m_volatiles_total=0;
      m_volatiles_max  =1024;
     }
//--- try to find our symbol
   for(i=0,sv=m_volatiles;i<m_volatiles_total;i++,sv++)
      if(strcmp(sv->symbol,symbol->symbol)==0)
        {
         //--- calculate the current price
         current=(inf->bid+inf->ask)/2;
         //--- insert the new price change
         if(sv->buffer_position>=PRICE_BUFFER_SIZE) sv->buffer_position=0;
         sv->buffer[sv->buffer_position]=fabs(current-sv->last_price);
         sv->buffer_position++;
         //--- maybe, the amount of changes has been grown?
         if(sv->buffer_position>sv->buffer_size) sv->buffer_size=sv->buffer_position;
         //--- extract the spread for calculations
         if((spread=symbol->spread)<1)
            if((spread=DecPow(symbol->digits)*fabs(inf->ask-inf->bid))<1) { m_sync.Unlock(); return; }
         //--- check for movement (considerable change of prices)
         if(sv->process_allow==TRUE && DecPow(symbol->digits)*sv->buffer[sv->buffer_position-1]>=spread*3)
           {
            //--- enable gap mode
            sv->process_allow=FALSE;
            //--- tell about it
            Out(CmdOK,"DealerHelper","'%d': %s gap mode enabled",m_manager.login,symbol->symbol);
           }
         else if(sv->buffer_size>2)
              {
               //--- calculate the moving average of the price changes
               for(j=0,sma=0;j<sv->buffer_size;j++) sma+=sv->buffer[j];
               sma/=sv->buffer_size;
               //--- so what is there?
               if(sv->process_allow==TRUE && (DecPow(symbol->digits)*sma)>=spread)
                 {
                  //--- enable gap mode
                  sv->process_allow=FALSE;
                  //--- tell about it
                  Out(CmdOK,"DealerHelper","'%d': %s gap mode disabled",m_manager.login,symbol->symbol);
                 }
               else if(sv->process_allow==FALSE && (DecPow(symbol->digits)*sma)<spread)
                    {
                     //--- disable gap mode
                     sv->process_allow=TRUE;
                     //--- tell about it
                     Out(CmdOK,"DealerHelper","'%d': %s gap mode disabled",m_manager.login,symbol->symbol);
                    }
              }
         //--- set the latest price
         sv->last_price=current;
         //--- that's like all
         m_sync.Unlock();
         return;
        }
//--- we can get here if we haven't found a symbol, check the space...
   if(m_volatiles_total>=m_volatiles_max)
     {
      //--- allocate more space
      if((temp=new SymbolVolatile[m_volatiles_max+1024])==NULL) { m_sync.Unlock(); return; }
      //--- copy everything we have, there
      memcpy(temp,m_volatiles,m_volatiles_total*sizeof(SymbolVolatile));
      //--- change for a larger buffer
      delete[] m_volatiles;
      m_volatiles     =temp;
      m_volatiles_max+=1024;
     }
//--- add a new symbol, the processing is disabled by default
   COPY_STR(m_volatiles[m_volatiles_total].symbol,symbol->symbol);
   m_volatiles[m_volatiles_total].process_allow  =FALSE;
   m_volatiles[m_volatiles_total].buffer_size    =0;
   m_volatiles[m_volatiles_total].buffer_position=0;
   m_volatiles[m_volatiles_total].last_price     =(inf->bid+inf->ask)/2;;
   m_volatiles_total++;
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::CheckVolatile(LPCSTR symbol)
  {
   int i;
//--- checking
   if(symbol==NULL) return(FALSE);
//--- find the necessary symbol
   m_sync.Lock();
   for(i=0;i<m_volatiles_total;i++)
      if(strcmp(m_volatiles[i].symbol,symbol)==0)
        {
         //--- receive status
         i=m_volatiles[i].process_allow;
         //--- unlock
         m_sync.Unlock();
         //--- return status
         return(i);
        }
   m_sync.Unlock();
//--- 
   return(FALSE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CProcessor::Out(const int code,LPCSTR ip,LPCSTR msg,...) const
  {
   char buffer[1024];
//--- ��������
   if(ExtServer==NULL || msg==NULL) return;
//--- ������������� ������
   va_list arg_ptr;
   va_start(arg_ptr,msg);
   _vsnprintf(buffer,sizeof(buffer)-1,msg,arg_ptr);
   va_end(arg_ptr);
//--- �������
   ExtServer->LogsOut(code,ip,buffer);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+


//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|  ���������� ����������                                           |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|  �������                                                         |
//+------------------------------------------------------------------+
int         GetIntParam(LPCSTR string,LPCSTR param,int *data);
int         GetStrParam(LPCSTR string,LPCSTR param,char *buf,int len);
void        ClearLF(char *line);
double      CalcToDouble(const int price,int floats);
double      NormalizeDouble(const double val, int digits);
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include <math.h>
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
static const double ExtDecimalArray[9]={ 1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0, 100000000.0 };  
//+------------------------------------------------------------------+
//|                          �������                                 |
//+------------------------------------------------------------------+
//| ����� ������ ����������                                          |
//+------------------------------------------------------------------+
int GetIntParam(LPCSTR string,LPCSTR param,int *data)
  {
//--- ��������
   if(string==NULL || param==NULL || data==NULL) return(FALSE);
//--- ���������� �������
   while(*string==' ') string++;
   if(memcmp(string,param,strlen(param))!=0)     return(FALSE);
//--- ��� ���������
   *data=atoi(&string[strlen(param)]);
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| ������ ���������� ���������                                      |
//+------------------------------------------------------------------+
int GetStrParam(LPCSTR string,LPCSTR param,char *buf,const int maxlen)
  {
   int i=0;
//--- ��������
   if(string==NULL || param==NULL || buf==NULL)  return(FALSE);
//--- ���������� �������
   while(*string==' ') string++;
   if(memcmp(string,param,strlen(param))!=0)     return(FALSE);
//--- ����� ���������
   string+=strlen(param);
   while(*string!=0 && i<maxlen) { *buf++=*string++; i++; }
   *buf=0;
//--- ��� ���������
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ClearLF(char *line)
  {
//---
   if(line==NULL) return;
   while(*line>31 || *line<0 || *line==9 || *line==27) line++;
   *line=0;
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double __fastcall NormalizeDouble(const double val,int digits)
  {
   if(digits<0) digits=0;
   if(digits>8) digits=8;
//---
   const double p=ExtDecimalArray[digits];
   return((val>=0.0) ? (double(__int64(val*p+0.5000001))/p) : (double(__int64(val*p-0.5000001))/p));
  }
//+------------------------------------------------------------------+

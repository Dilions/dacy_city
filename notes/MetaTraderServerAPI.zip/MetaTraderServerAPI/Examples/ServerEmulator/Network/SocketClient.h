//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct ServerCfg
  {
   char              password_quotes[32];     // password for "LOGIN QUOTES pass"
   char              password_trades[32];     // password for "LOGIN TRADES pass"
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CSocketClient
  {
protected:
   SOCKET            m_socket;                  // network socket
   HANDLE            m_thread;                  // thread handle
   volatile int      m_finished;                // stop flag
   ServerCfg        *m_cfg;                     // link to server configuration (read only)
   CSocketClient    *m_next;                    // link to next connection

public:
                     CSocketClient();
   virtual          ~CSocketClient() { Shutdown(); }

   virtual void      Shutdown(void);
   void              Close(void);
   int               Finished(void)            { return(m_finished); }
   CSocketClient*    Next(void)                { return(m_next);     }
   void              Next(CSocketClient *next) { m_next=next;        }

   int               StartClient(const SOCKET sock,LPCSTR ip,ServerCfg *cfg);

protected:
   void              PumpQuotes(void);
   void              PumpTrades(void);
   int               IsReadible();
   int               ReadString(char *buf,int maxlen);
   int               SendString(char *str,int len);
   int               ProcessTrade(char *str);
   virtual void      ThreadProcess(void);
   static UINT __stdcall ThreadWrapper(LPVOID pParam);
  };
//+------------------------------------------------------------------+

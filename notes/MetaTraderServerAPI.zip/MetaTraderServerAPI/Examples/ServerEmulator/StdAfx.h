//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//--- exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN
//---
#include <windows.h>
#include <winsock2.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
//--- macros
#define TERMINATE_STR(str) str[sizeof(str)-1]=0;
#define COPY_STR(dst,src) { strncpy(dst,src,sizeof(dst)-1); dst[sizeof(dst)-1]=0; }
//+------------------------------------------------------------------+

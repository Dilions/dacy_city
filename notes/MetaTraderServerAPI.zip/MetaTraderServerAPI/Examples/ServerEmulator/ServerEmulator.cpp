//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include <conio.h>
#include "network\socketserver.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int main(int argc, char* argv[])
  {
   CSocketServer srv;
   WSADATA       wsa;
//--- just a banner
   printf("Server Emulator for quotes and trades\n");
   printf("Copyright 2001-2014, MetaQuotes Software Corp.\n\n");
//--- initialized winsock 2
   if(WSAStartup(0x0202,&wsa)!=0)
     {
      printf("Winsock initialization failed\n");
      return(-1);
     }
//--- start the server
   srv.Initialize();
   if(srv.StartServer(4444)==FALSE) return(-1);
   printf("Press any key to stop server...\n");
//--- wait untill finished
   while(srv.Finished()==FALSE)
     {
      Sleep(500);
      if(_kbhit()) { _getch(); break; }
     }
   srv.Shutdown();
//--- finish
   WSACleanup();
   return(0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

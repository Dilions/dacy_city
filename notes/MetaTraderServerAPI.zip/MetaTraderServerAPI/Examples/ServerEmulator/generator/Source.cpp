//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Source.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CSource::CSource()
  {
//---
   strcpy(m_si[0].security,"USDCHF"); m_si[0].trend=TREND_UNKNOWN;
   m_si[0].min=1.4900; m_si[0].max =1.5800;
   m_si[0].bid=1.5000; m_si[0].ask=1.5005;
   m_si[0].point=0.0001;

   strcpy(m_si[1].security,"GBPUSD"); m_si[1].trend=TREND_UNKNOWN;
   m_si[1].min=1.5900; m_si[1].max =1.6200;
   m_si[1].bid=1.6000; m_si[1].ask=1.6005;
   m_si[1].point=0.0001;

   strcpy(m_si[2].security,"USDJPY"); m_si[2].trend=TREND_UNKNOWN;
   m_si[2].min=104.60; m_si[2].max =109.50;
   m_si[2].bid=106.50; m_si[2].ask=106.58;
   m_si[2].point=0.01;

   strcpy(m_si[3].security,"EURUSD"); m_si[3].trend=TREND_UNKNOWN;
   m_si[3].min=0.9200; m_si[3].max =1;
   m_si[3].bid=0.9600; m_si[3].ask=0.9605;
   m_si[3].point=0.0001;

   strcpy(m_si[4].security,"USDCAD"); m_si[4].trend=TREND_UNKNOWN;
   m_si[4].min=0.9200; m_si[4].max =1;
   m_si[4].bid=0.9600; m_si[4].ask=0.9605;
   m_si[4].point=0.0001;

   strcpy(m_si[5].security,"GBPCHF"); m_si[5].trend=TREND_UNKNOWN;
   m_si[5].min=0.9200; m_si[5].max =1;
   m_si[5].bid=0.9600; m_si[5].ask=0.9605;
   m_si[5].point=0.0001;

   strcpy(m_si[6].security,"GBPJPY"); m_si[6].trend=TREND_UNKNOWN;
   m_si[6].min=150.00; m_si[6].max =160.00;
   m_si[6].bid=159.00; m_si[6].ask=159.05;
   m_si[6].point=0.01;

   strcpy(m_si[7].security,"EURCHF"); m_si[7].trend=TREND_UNKNOWN;
   m_si[7].min=0.9200; m_si[7].max =1;
   m_si[7].bid=0.9600; m_si[7].ask=0.9605;
   m_si[7].point=0.0001;

   strcpy(m_si[8].security,"EURGBP"); m_si[8].trend=TREND_UNKNOWN;
   m_si[8].min=0.9200; m_si[8].max =1;
   m_si[8].bid=0.9600; m_si[8].ask=0.9605;
   m_si[8].point=0.0001;

   strcpy(m_si[9].security,"EURJPY"); m_si[9].trend=TREND_UNKNOWN;
   m_si[9].min=92.00;  m_si[9].max =98.00;
   m_si[9].bid=96.00;  m_si[9].ask=96.05;
   m_si[9].point=0.01;
   m_total=10;
//---
   m_counter=0;
   m_sleeptime=700;  // ms
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CSource::~CSource() { }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CSource::ReadTick(TickInfo *inf)
  {
   int    pr,pr2,add;
//---
   Sleep(m_sleeptime);
//--- check trend
   if(m_si[m_counter].trend==TREND_UNKNOWN) // lets change
     {
      pr=rand()&127;
      pr2=(int)(((m_si[m_counter].max-m_si[m_counter].bid)*127)/(m_si[m_counter].max-m_si[m_counter].min));
      if(pr<pr2) m_si[m_counter].trend=TREND_UP;
      else       m_si[m_counter].trend=TREND_DOWN;
      //--- find new target
      if(m_si[m_counter].trend==TREND_UP)
           m_si[m_counter].target=m_si[m_counter].ask+(m_si[m_counter].max-m_si[m_counter].ask)/2;
      else m_si[m_counter].target=m_si[m_counter].ask-(m_si[m_counter].ask-m_si[m_counter].min)/2;
     }
//---
   pr=rand()&31; add=rand()&1;
   if(m_si[m_counter].trend==TREND_DOWN)  add=-add;
   if(pr>15) m_si[m_counter].bid+=add*m_si[m_counter].point;
   else      m_si[m_counter].bid-=add*m_si[m_counter].point;
   m_si[m_counter].ask=m_si[m_counter].bid+(2+(rand()&1))*m_si[m_counter].point;
//--- target reached?
   if(m_si[m_counter].trend==TREND_DOWN && m_si[m_counter].target>m_si[m_counter].ask) m_si[m_counter].trend=TREND_UNKNOWN;
   if(m_si[m_counter].trend==TREND_UP   && m_si[m_counter].target<m_si[m_counter].ask) m_si[m_counter].trend=TREND_UNKNOWN;
//---
   strcpy(inf->security,m_si[m_counter].security);
   inf->bid=m_si[m_counter].bid;
   inf->ask=m_si[m_counter].ask;
   inf->timerel=3+(rand()&3);
//---
   if((rand()&127)>120) m_si[m_counter].trend=TREND_UNKNOWN;
   m_counter++; if(m_counter>=m_total) m_counter=0;
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

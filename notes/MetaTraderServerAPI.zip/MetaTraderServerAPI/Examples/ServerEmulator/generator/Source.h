//+------------------------------------------------------------------+
//|                                                  Server Emulator |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#define MAX_SECURITIES 64

struct TickInfo
  {
   char              security[8];     // "USD/JPY"
   double            bid,ask;
   int               timerel;
  };

struct SourceInfo
  {
   char              security[8];   // "USDJPY"
   double            min,max;       // 110, 121
   double            bid,ask;
   int               trend;         // ������� �����
   double            target;
   double            point;
  };

enum EnTrendModes { TREND_UNKNOWN=0,TREND_UP,TREND_DOWN,TREND_NONE };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CSource
  {
protected:
   SourceInfo        m_si[MAX_SECURITIES+2];
   int               m_total;
   int               m_counter;
   int               m_sleeptime;

public:
                     CSource();
                    ~CSource();
   int               ReadTick(TickInfo *inf);
  };
//+------------------------------------------------------------------+

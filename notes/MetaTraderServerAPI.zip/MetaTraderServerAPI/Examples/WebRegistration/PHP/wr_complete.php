<?
//--- setup page encondig
header("Content-Type: text/html; charset=".T_PAGE_ENCODING);
//--- show page
include('wr_complete.phtml');
?>

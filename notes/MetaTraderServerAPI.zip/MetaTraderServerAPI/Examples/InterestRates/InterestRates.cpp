//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Config\Configuration.h"
//---
PluginInfo          ExtPluginInfo={ "Interest Rates",102,"MetaQuotes Software Corp.",{0} };
int                 ExtMinimumFreeMargin=0;
char                ExtNoSwapGroups[512]="";
CServerInterface   *ExtServer=NULL;
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID /*lpReserved*/)
  {
   char tmp[256],*cp;
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
        //--- create configuration filename
        GetModuleFileName((HMODULE)hModule,tmp,sizeof(tmp)-5);
        if((cp=strrchr(tmp,'.'))!=NULL) { *cp=0; strcat(tmp,".ini"); }
        //--- load configuration
        ExtConfig.Load(tmp);
        break;

      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
        break;

      case DLL_PROCESS_DETACH:
        break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Get saved settings                                               |
//+------------------------------------------------------------------+
void RealoadConfiguration(void)
  {
   char  tmp[256];
//--- retrieve settings
   ExtConfig.GetInteger("Minimum Free Margin",&ExtMinimumFreeMargin,"0");
   ExtConfig.GetString("No Swap Groups",ExtNoSwapGroups,sizeof(ExtNoSwapGroups)-2,"");
//--- add last comma
   if(ExtNoSwapGroups[0]!=0)
     if(ExtNoSwapGroups[strlen(ExtNoSwapGroups)-1]!=',') strcat(ExtNoSwapGroups,",");
//--- show init message
   _snprintf(tmp,sizeof(tmp)-1,"initialized (minimum $%d)",ExtMinimumFreeMargin);
   ExtServer->LogsOut(CmdOK,"InterestRates",tmp);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL)                        return(FALSE);
   if(server->Version()!=ServerApiVersion) return(FALSE);
//--- save server interface link
   ExtServer=server;
//--- get saved settings
   RealoadConfiguration();
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Standard configuration functions                                 |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgAdd(const PluginCfg *cfg)
  {
   int ret;
//---
   ret=ExtConfig.Add(cfg);
   RealoadConfiguration();
//---
   return(ret);
  }
int APIENTRY MtSrvPluginCfgSet(const PluginCfg *values,const int total)
  {
   int ret;
//---
   ret=ExtConfig.Set(values,total);
   RealoadConfiguration();
//---
   return(ret);
  }
int APIENTRY MtSrvPluginCfgDelete(LPCSTR name)
  {
   int ret;
//---
   ret=ExtConfig.Delete(name);
   RealoadConfiguration();
//---
   return(ret);
  }
int APIENTRY MtSrvPluginCfgGet(LPCSTR name,PluginCfg *cfg)              { return ExtConfig.Get(name,cfg);     }
int APIENTRY MtSrvPluginCfgNext(const int index,PluginCfg *cfg)         { return ExtConfig.Next(index,cfg);   }
int APIENTRY MtSrvPluginCfgTotal()                                      { return ExtConfig.Total();           }
//+------------------------------------------------------------------+
//| Hook on daily interest calculation                               |
//+------------------------------------------------------------------+
int APIENTRY MtSrvUserInterestDaily(const UserRecord *user,const ConGroup *group,const double freemargin)
  {
//--- don't calculate interest if client don't have enough free margin
   if(freemargin<ExtMinimumFreeMargin) return(TRUE); // we calculate interest on one's own
//--- let server calculate it
   return(FALSE);
  }
//+------------------------------------------------------------------+
//| Hook on end of day swap calculation                              |
//+------------------------------------------------------------------+
int APIENTRY MtSrvTradeRollover(TradeRecord *trade,const double value,const OverNightData *data)
  {
   UserRecord user;
   char       tmp[512];
//--- check parameters
   if(trade==NULL || data==NULL || ExtNoSwapGroups[0]==0) return(FALSE);
//--- get client information
   if(ExtServer)
     if(ExtServer->ClientsUserInfo(trade->login,&user))
       {
        COPY_STR(tmp,ExtNoSwapGroups);
        char *token=strtok(tmp,",");
        while(token!=NULL)
          {
           //--- just skip swaps if equal
           if(strcmp(token,user.group)==0) { trade->storage=0; return(TRUE); }
           //--- next token
           token=strtok(NULL,",");
          }
       }
//---
   return(FALSE);
  }
//+------------------------------------------------------------------+

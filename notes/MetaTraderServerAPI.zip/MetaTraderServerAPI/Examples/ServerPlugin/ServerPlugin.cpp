//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "sync.h"
#include "..\..\include\MT4ServerAPI.h"
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
PluginInfo        ExtPluginInfo={ "DataFeed Catcher",101,"MetaQuotes Software Corp.",{0} };
char              ExtProgramPath[MAX_PATH]="";
CSync             ExtSync;
CServerInterface *ExtServer=NULL;
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
  {
   char *cp;
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
         //--- current folder
         GetModuleFileName((HMODULE)hModule,ExtProgramPath,sizeof(ExtProgramPath)-1);
         cp=&ExtProgramPath[strlen(ExtProgramPath)-2];
         while(cp>ExtProgramPath && *cp!='\\') cp--; *cp=0;
         //---
         break;
      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
         break;
      case DLL_PROCESS_DETACH:
         break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL)                        return(FALSE);
   if(server->Version()!=ServerApiVersion) return(FALSE);
//--- save server interface link
   ExtServer=server;
   ExtServer->LogsOut(CmdOK,"plugin","DataFeed Catcher: initialized");
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| DataFeed                                                         |
//+------------------------------------------------------------------+
void APIENTRY MtSrvFeederData(const ConFeeder *feed,FeedData *inf)
  {
   char  tmp[MAX_PATH];
   FILE *out;
//--- checking
   if(inf==NULL)          return;
   if(inf->ticks_count<1) return;
//--- open a file
   _snprintf(tmp,sizeof(tmp)-1,"%s\\ticks.txt",ExtProgramPath);
   ExtSync.Lock();
   if((out=fopen(tmp,"at"))!=NULL)
     {
      for(int i=0;i<inf->ticks_count;i++)
            fprintf(out,"%s: %.5lf / %.5lf\n",inf->ticks[i].symbol,inf->ticks[i].bid,inf->ticks[i].ask);
      fclose(out);
     }
   ExtSync.Unlock();
//---
  }
//+------------------------------------------------------------------+

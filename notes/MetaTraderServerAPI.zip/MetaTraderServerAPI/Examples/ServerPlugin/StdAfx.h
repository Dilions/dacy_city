//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//--- exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN
//---
#include <windows.h>
#include <time.h>
#include <stdio.h>
//+------------------------------------------------------------------+

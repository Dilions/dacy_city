//+------------------------------------------------------------------+
//|                                                           Syslog |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct LogItem
  {
   char              message[256];
   LogItem          * next;
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CLogsDispatcher
  {
   LogItem          *m_head,*m_end;
   SOCKET            m_socket;
   HANDLE            m_thread;
   int               m_stopflag;
   CSync             m_sync;           // ����������� ������ �����
   char              m_server[256];
public:
                     CLogsDispatcher();
                    ~CLogsDispatcher();
   //---
   int               Initialize(void);
   int               Shutdown(void);
   //---
   int               Add(const LogInfo *info);
private:
   //---
   int               Connect(void);
   void              Close(void);
   //---
   void              Process(void);
   //---
   static UINT __stdcall ThreadFuntion(LPVOID pParam);
  };
//+------------------------------------------------------------------+
extern CLogsDispatcher ExtLogsDisp;
//+------------------------------------------------------------------+

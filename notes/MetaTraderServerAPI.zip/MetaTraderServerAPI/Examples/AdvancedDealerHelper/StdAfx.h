//+------------------------------------------------------------------+
//|                                           Advanced Dealer Helper |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//--- exclude rarely-used stuff from Windows headers
#define WIN32_LEAN_AND_MEAN
//--- ����������� ���������
#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <math.h>
#include <io.h>
#include <sys/stat.h>
#include <math.h>
//--- MetaTrader Server API
#include "..\..\include\MT4ServerAPI.h"
//--- ���� �����
#include "common\common.h"
#include "config\StringFile.h"
#include "config\Configuration.h"
//--- �������
#define TERMINATE_STR(str) { str[sizeof(str)-1]=0;                                 }
#define COPY_STR(dst,src)  { strncpy(dst,src,sizeof(dst)-1); dst[sizeof(dst)-1]=0; }
//+------------------------------------------------------------------+

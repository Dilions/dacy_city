//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
//---
PluginInfo        ExtPluginInfo={ "Telnet Extension",100,"MetaQuotes Software Corp.",{0} };
CServerInterface *ExtServer=NULL;
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved)
  {
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
        break;
      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
        break;
      case DLL_PROCESS_DETACH:
        break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL)                        return(FALSE);
   if(server->Version()!=ServerApiVersion) return(FALSE);
//--- save server interface link
   ExtServer=server;
   ExtServer->LogsOut(CmdOK,"TelnetExtension","initialized");
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| ���������� ������ �������                                        |
//+------------------------------------------------------------------+
int ParseUserGroup(char *auth,char *result,const int maxlen)
  {
   char       *cp;
   UserRecord  us;
   int         login;
//--- checking
   if(auth==NULL || result==NULL || ExtServer==NULL) return(FALSE);
//--- parse login
   login=atoi(auth);
   if(login<1 || (cp=strstr(auth,"|"))==NULL)               { strcpy(result,"Invalid Request");  return(TRUE); }
   if(ExtServer->ClientsUserInfo(login,&us)==FALSE)         { strcpy(result,"Invalid Login");    return(TRUE); }
//--- lets check password
   if(ExtServer->ClientsCheckPass(login,cp+1,FALSE)==FALSE) { strcpy(result,"Invalid Login");    return(TRUE); }
   if(us.enable!=TRUE)                                      { strcpy(result,"Account Disabled"); return(TRUE); }
//---
   sprintf(result,"%s\r\n",us.group);
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Telnet Extension entry                                           |
//| Example (dont forget to send 'W' for telnet mode):               |
//|    request: USERGROUP-login|password                             |
//|    answer:  demoforex                                            |
//+------------------------------------------------------------------+
int APIENTRY MtSrvTelnet(const ULONG ip,char *buf,const int maxlen)
  {
//--- checking
   if(buf==NULL || maxlen<1) return(0);
//--- parsing
   if(_stricmp(buf,"WHO ARE YOU?")==0)
     {
      _snprintf(buf,maxlen-1,"%s %d.%02d plugin\r\nCopyright � 2004, %s\r\n",
                             ExtPluginInfo.name,
                             ExtPluginInfo.version/100,ExtPluginInfo.version%100,
                             ExtPluginInfo.copyright);
      return(strlen(buf)+1);
     }
   if(memcmp(buf,"USERGROUP-",10)==0)
     if(ParseUserGroup(buf+10,buf,maxlen)==TRUE) return(strlen(buf)+1);
//---
   return(0);
  }
//+------------------------------------------------------------------+

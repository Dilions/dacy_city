//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Base\MarketMakersBase.h"
//---
PluginInfo          ExtPluginInfo={ "MarketMaker Collector",101,"MetaQuotes Software Corp.",{0} };
CSync               ExtSync;
CServerInterface   *ExtServer=NULL;
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID /*lpReserved*/)
  {
   char *cp;
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
         //--- current folder
         GetModuleFileName((HMODULE)hModule,ExtProgramPath,sizeof(ExtProgramPath)-1);
         cp=&ExtProgramPath[strlen(ExtProgramPath)-2];
         while(cp>ExtProgramPath && *cp!='\\') cp--; *cp=0;
         break;
      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
         break;
      case DLL_PROCESS_DETACH:
         break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL)                        return(FALSE);
   //   if(server->Version()!=ServerApiVersion) return(FALSE);
//--- save server interface link
   ExtServer=server;
   ExtServer->LogsOut(CmdOK,"plugin","MarketMaker Collector: initialized");
//--- create base
   if(ExtMarketMakersBase==NULL)
      if((ExtMarketMakersBase=new CMarketMakersBase())==NULL) return(FALSE);
//--- read configuration
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Clean plugin data                                                |
//+------------------------------------------------------------------+
void APIENTRY MtSrvCleanup(void)
  {
//--- create base
   if(ExtMarketMakersBase!=NULL)
     {
      delete ExtMarketMakersBase;
      ExtMarketMakersBase=NULL;
     }
//---
  }
//+------------------------------------------------------------------+
//| Intercept orders adding                                          |
//+------------------------------------------------------------------+
void APIENTRY MtSrvTradesAdd(TradeRecord *trade,UserInfo *user,const ConSymbol *symb)
  {
//--- process order
   if(ExtMarketMakersBase!=NULL) ExtMarketMakersBase->TradeAdd(trade,user,symb);
//---
  }
//+------------------------------------------------------------------+
//| Intercept orders closing/updating                                |
//+------------------------------------------------------------------+
void APIENTRY MtSrvTradesUpdate(TradeRecord *trade,UserInfo *user,const int mode)
  {
//--- process order
   if(ExtMarketMakersBase!=NULL) ExtMarketMakersBase->TradeClose(trade,user,mode);
//---
  }
//+------------------------------------------------------------------+

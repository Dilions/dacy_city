//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "logger.h"

//---
char    ExtProgramPath[200]="";
CLogger ExtLogger;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CLogger::CLogger(void): m_file(NULL)
  {
//---
   m_prebuf=new char[32768];
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CLogger::~CLogger(void)
  {
   m_sync.Lock();
//---
   if(m_file!=NULL)    { fclose(m_file);     m_file=NULL;    }
   if(m_prebuf!=NULL)  { delete[] m_prebuf;  m_prebuf=NULL;  }
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CLogger::Out(LPCSTR msg,...)
  {
   char       tmp[512];
   SYSTEMTIME st;
   va_list    arg_ptr;
//---
   if(msg==NULL || m_prebuf==NULL) return;
//---
   GetLocalTime(&st);
//---
   m_sync.Lock();
   va_start(arg_ptr, msg);
   vsprintf(m_prebuf,msg,arg_ptr);
   va_end(arg_ptr);
//---
   if(m_file==NULL)
     {
      _snprintf(tmp,sizeof(tmp)-1,"%s\\MarketMakerCollector.log",ExtProgramPath);
      m_file=fopen(tmp,"at");
     }
//---
   if(m_file!=NULL)
     {
      fprintf(m_file,"%04d.%02d.%02d %02d:%02d:%02d %s\n",
                    st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,m_prebuf);
      fflush(m_file);
     }
//---
   printf("%02d:%02d:%02d %s\n",st.wHour,st.wMinute,st.wSecond,m_prebuf);
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+

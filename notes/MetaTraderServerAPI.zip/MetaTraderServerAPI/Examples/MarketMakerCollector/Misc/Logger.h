//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CLogger
  {
   CSync             m_sync;
   FILE             *m_file;
   char             *m_prebuf;

public:
                     CLogger(void);
                    ~CLogger(void);
   void              Out(LPCSTR msg,...);
  };

extern CLogger ExtLogger;
extern char    ExtProgramPath[200];
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int               GetIntParam(LPCSTR string,LPCSTR param,int *data);
int               GetStrParam(LPCSTR string,LPCSTR param,char *buf,int len);
void              ClearLF(char *line);
double            CalcToDouble(const int price,int floats);
double __fastcall NormalizeDouble(const double val,int digits);
double            Points(const int digits);
int               CheckGroup(char* grouplist, char *group);
char*             insert(void *base,const void *elem,size_t num,const size_t width,int(__cdecl *compare)( const void *elem1,const void *elem2 ));
//+------------------------------------------------------------------+

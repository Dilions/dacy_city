//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include <math.h>
//+------------------------------------------------------------------+
//| Constants                                                        |
//+------------------------------------------------------------------+
static const double ExtDecimalArray[9] ={ 1.0, 10.0, 100.0, 1000.0, 10000.0, 100000.0, 1000000.0, 10000000.0, 100000000.0 };
static const double ExtDecFractArray[9]={ 1.0, 0.1,  0.01,  0.001,  0.0001 , 0.00001,  0.000001,   0.0000001, 0.00000001   };
//+------------------------------------------------------------------+
//| Getting string parameters                                        |
//+------------------------------------------------------------------+
int GetIntParam(LPCSTR string,LPCSTR param,int *data)
  {
//---
   if(string==NULL || param==NULL || data==NULL) return(FALSE);
//---
   while(*string==' ') string++;
   if(memcmp(string,param,strlen(param))!=0)     return(FALSE);
//---
   *data=atoi(&string[strlen(param)]);
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Getting string parameters                                        |
//+------------------------------------------------------------------+
int GetStrParam(LPCSTR string,LPCSTR param,char *buf,const int maxlen)
  {
   int i=0;
//--- check
   if(string==NULL || param==NULL || buf==NULL)  return(FALSE);
//--- skip spaces
   while(*string==' ') string++;
   if(memcmp(string,param,strlen(param))!=0)     return(FALSE);
//---
   string+=strlen(param);
   while(*string!=0 && i<maxlen) { *buf++=*string++; i++; }
   *buf=0;
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ClearLF(char *line)
  {
//---
   if(line==NULL) return;
   while(*line>31 || *line<0 || *line==9 || *line==27) line++;
   *line=0;
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double __fastcall NormalizeDouble(const double val,int digits)
  {
   if(digits<0) digits=0;
   if(digits>8) digits=8;
//---
   const double p=ExtDecimalArray[digits];
   return((val>=0.0) ? (double(__int64(val*p+0.5000001))/p) : (double(__int64(val*p-0.5000001))/p));
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double Points(const int digits)
  {
   if(digits<0 || digits>8) return(0);
//---
   return ExtDecFractArray[digits];
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CheckTemplate(char* expr,char* tok_end,char* group,char* prev,int* deep)
  {
   char  tmp=0;
   char *lastwc,*prev_tok,*cp;
//--- 
   if((*deep)++>=10) return(FALSE);
//--- 
   while(*expr=='*' && expr!=tok_end) expr++;
   if(expr==tok_end) return(TRUE);
//--- 
   lastwc=expr;
   while(*lastwc!='*' && *lastwc!=0) lastwc++;
//--- 
   if((tmp=*(lastwc))!=0)
     {
      tmp=*(lastwc);*(lastwc)=0;
      if((prev_tok=strstr(group,expr))==NULL) { if(tmp!=0) *(lastwc)=tmp; return(FALSE); }
      *(lastwc)=tmp;
     }
   else
     {
      //---
      cp=group+strlen(group);
      for(;cp>=group;cp--)
         if(*cp==expr[0] && strcmp(cp,expr)==0)
            return(TRUE);
      return(FALSE);
     }
//---
   if(prev!=NULL &&  prev_tok<=prev) return(FALSE);
   prev=prev_tok;
//---
   group=prev_tok+(lastwc-expr-1);
//---
   if(lastwc!=tok_end) return CheckTemplate(lastwc,tok_end,group,prev,deep);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CheckGroup(char* grouplist, char *group)
  {
//---
   if(grouplist==NULL || group==NULL) return(FALSE);
//---
   char *tok_start=grouplist,end;
   int  res=TRUE,deep=0,normal_mode;
   while(*tok_start!=0)
     {
      //---
      while(*tok_start==',') tok_start++;
      //---
      if(*tok_start=='!') { tok_start++; normal_mode=FALSE; }
      else                 normal_mode=TRUE;
      //---
      char *tok_end=tok_start;
      while(*tok_end!=',' && *tok_end!=0) tok_end++;
      end=*tok_end; *tok_end=NULL;
      //---
      char *tp=tok_start;
      char *gp=group, *prev=NULL;
      //---
      res=TRUE;
      while(tp!=tok_end && *gp!=NULL)
        {
         //---
         if(*tp=='*')
           {
            deep=0;
            if((res=CheckTemplate(tp,tok_end,gp,prev,&deep))==TRUE)
              {
               *tok_end=end;
               return(normal_mode);
              }
            break;
           }
         //---
         if(*tp!=*gp) { *tok_end=end; res=FALSE; break; }
         tp++; gp++;
        }
      //---
      *tok_end=end;
      //---
      if(*gp==NULL && (tp==tok_end || *tp=='*') && res==TRUE) return(normal_mode);
      //---
      if(*tok_end==0) break;
      tok_start=tok_end+1;
     }
//---
   return(FALSE);
  }
//+------------------------------------------------------------------+
//| The function of record insert into the ordered array regarding   |
//| the sorting                                                      |
//+------------------------------------------------------------------+
char* insert(void *base,const void *elem,size_t num,const size_t width,int(__cdecl *compare)( const void *elem1,const void *elem2 ))
  {
//---
   if(base==NULL || elem==NULL || compare==NULL) return(NULL);
//---
   if(num<1) { memcpy(base,elem,width); return(char*)(base); }
//---
   register char *lo=(char *)base;
   register char *hi=(char *)base+(num-1) * width, *end=hi;
   register char *mid;
   unsigned int   half;
   int            result;
//---
   while(num>0)
     {
      half=num/2;
      mid=lo+half*width;
      //---
      if((result=compare(elem,mid))>0) // data[mid]<elem
        {
         lo  =mid+width;
         num =num-half-1;
        }
      else if(result<0)                // data[mid]>elem
           {
            num=half;
           }
         else                             // data[mid]==elem
            return(NULL);
     }
//---
   memmove(lo+width,lo,end-lo+width);
   memcpy(lo,elem,width);
//---
   return(lo);
  }
//+------------------------------------------------------------------+

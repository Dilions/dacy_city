//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
#include "..\Misc\sync.h"

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct SymbolInfo
  {
   char              symbol[12];
   int               spread;
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct MarketMaker
  {
   UserInfo          info;               // user info
   char              groups[256];        // market maker groups
   SymbolInfo        symbols[1024];        // symbols spread info
   int               symbols_total;      // total count of symbols
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
struct OrdersPair
  {
   int               order;
   int               hedge_order;
   MarketMaker*      market_maker;
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CMarketMakersBase
  {
   CSync             m_sync;
   MarketMaker       m_makers[32];
   int               m_makers_total;
   //---
   SymbolInfo        m_symbols[1024];
   int               m_symbols_total;
   //---
   OrdersPair       *m_orders;             // hedged orders base
   int               m_orders_total;       // hedged orders total
   int               m_orders_max;         // hedged orders max
public:
                     CMarketMakersBase();
                    ~CMarketMakersBase();
   //---
   void              Initialize();
   void              TradeAdd(TradeRecord *trade,UserInfo *user,const ConSymbol *symb);
   void              TradeClose(TradeRecord *trade,UserInfo *user,const int mode);

private:
   int               TradeAddCache(const int order,const int hedge_order,MarketMaker *maker);
   int               UserCheck(const UserInfo *user);
   int               SymbolSpread(const MarketMaker* maker,const char* symbol);
   //---
   static int        SortByOrder(const void *left,const void *right);
   static int        SearchByOrder(const void *left,const void *right);
   static int        SortBySymbol(const void *left,const void *right);
   static int        SearchBySymbol(const void *left,const void *right);
  };
//---
extern CMarketMakersBase *ExtMarketMakersBase;
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//| Configuration                                                    |
//+------------------------------------------------------------------+
class CConfiguration
  {
   int               m_mmaker_login;
   UserInfo          m_mmaker_info;
public:
                     CConfiguration();
                    ~CConfiguration();
   //--- config reading
   void              Initialize();
   //--- retrive params
   int               MarketMaker(void) { return(m_mmaker_login); }
   void              OrderAdd(const TradeRecord *trade, const UserInfo *user);
  };

extern CConfiguration ExtConfig;
//+------------------------------------------------------------------+

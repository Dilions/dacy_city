//+------------------------------------------------------------------+
//|                                            MetaTrader Server API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include <limits.h>
#include <float.h>
#include "MarketMakersBase.h"
#include "..\Misc\common.h"

CMarketMakersBase *ExtMarketMakersBase=NULL;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CMarketMakersBase::SortByOrder(const void *left,const void *right)
  {
   return((OrdersPair*)left)->order-((OrdersPair*)right)->order;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CMarketMakersBase::SearchByOrder(const void *left,const void *right)
  {
   return(*(int*)left)-((OrdersPair*)right)->order;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CMarketMakersBase::SortBySymbol(const void *left,const void *right)
  {
   return strcmp(((SymbolInfo*)left)->symbol,((SymbolInfo*)right)->symbol);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CMarketMakersBase::SearchBySymbol(const void *left,const void *right)
  {
   return strcmp((char*)left,((SymbolInfo*)right)->symbol);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CMarketMakersBase::CMarketMakersBase() : m_makers_total(0),m_symbols_total(0),
                                         m_orders(NULL),m_orders_total(0),m_orders_max(0)
  {
   ZeroMemory(m_makers,sizeof(m_makers));
   Initialize();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CMarketMakersBase::~CMarketMakersBase()
  {
   m_sync.Lock();
//---
   if(m_orders!=NULL)
     {
      delete[] m_orders; m_orders=NULL;
      m_orders_total=m_orders_max=0;
     }
//---
   m_makers_total=0;
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Read plugin config and initialize internal base                  |
//+------------------------------------------------------------------+
void CMarketMakersBase::Initialize(void)
  {
   UserRecord   user;
   UserInfo    *info;
   TradeRecord *trades,trade;
   OrdersPair  *pairs;
   MarketMaker *maker;
   int          i,total,pairs_total,login=0;
   char         tmp[MAX_PATH],groups[256]={0},*cp;
   FILE        *in;
   SymbolInfo   symbols[1024];
   int          symbols_total=0;

//---
   m_sync.Lock();
   _snprintf(tmp,sizeof(tmp)-1,"%s\\MarketMakerCollector.cfg",ExtProgramPath);
   if((in=fopen(tmp,"rt"))!=NULL)
     {
      while(fgets(tmp,sizeof(tmp)-1,in)!=NULL)
        {
         ClearLF(tmp);
         if(tmp[0]==';') continue;
         //--- read special spreads
         if(GetStrParam(tmp,"MarketMakerSpreads=",tmp,sizeof(tmp)-1)==TRUE)
           {
            if((cp=strchr(tmp,','))==NULL) continue;
            //---
            *cp=0;
            COPY_STR(symbols[symbols_total].symbol,tmp);
            symbols[symbols_total].spread=atoi(cp+1);
            symbols_total++;
            continue;
           }
         if(GetIntParam(tmp,"MarketMakerAccount=",&login)!=FALSE) continue;
         if(GetStrParam(tmp,"MarketMakerGroups=", groups,sizeof(groups)-1)!=FALSE)
           {
            if(ExtServer==NULL || login==0 || groups[0]==0) { login=0; groups[0]=0; symbols_total=0; continue; }
            //--- read client info
            if(ExtServer->ClientsUserInfo(login,&user)!=FALSE)
              {
               maker=&m_makers[m_makers_total];
               info =&maker->info;
               COPY_STR(maker->groups,groups);
               //--- copy UserInfo
               info->login    =login;
               COPY_STR(info->group,user.group);
               COPY_STR(info->name,user.name);
               info->credit   =user.credit;
               info->balance  =user.balance;
               info->leverage =user.leverage;
               //--- copy spread info
               if(symbols_total>0)
                 {
                  //--- copy & sort symbols
                  memcpy(maker->symbols,symbols,sizeof(SymbolInfo)*symbols_total);
                  maker->symbols_total=symbols_total;
                  qsort(maker->symbols,maker->symbols_total,sizeof(SymbolInfo),SortBySymbol);
                 }
               //--- retrieve orders
               pairs_total=0;
               if((trades=ExtServer->OrdersGetOpen(info,&total))!=NULL)
                 {
                  if(m_orders==NULL || (m_orders_total+total)>=m_orders_max)
                    {
                     if((pairs=new OrdersPair[m_orders_total+total+512])==NULL)
                       {
                        ExtLogger.Out("HedgeBase: no enough memory");
                        break;
                       }
                     //---
                     if(m_orders!=NULL)
                       {
                        if(m_orders_total>0) memcpy(pairs,m_orders,sizeof(OrdersPair)*m_orders_total);
                        delete[] m_orders;
                       }
                     m_orders    =pairs;
                     m_orders_max=m_orders_total+total+512;
                    }
                  //--- copy
                  for(i=0;i<total;i++)
                     if(ExtServer->OrdersGet(trades[i].magic,&trade)!=FALSE)
                       {
                        m_orders[m_orders_total].hedge_order =trades[i].order;
                        m_orders[m_orders_total].order       =trades[i].magic;
                        m_orders[m_orders_total].market_maker=&m_makers[m_makers_total];
                        m_orders_total++;
                       }
                  //--- clear
                  HEAP_FREE(trades); trades=NULL;
                 }
               //--- raise counter & clear
               m_makers_total++;
              }
            login=0; groups[0]=0; symbols_total=0;
           }
        }
      fclose(in);
      //--- sort orders
      if(m_orders_total>1)  qsort(m_orders, m_orders_total, sizeof(OrdersPair),SortByOrder);
     }
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//| Check user acceptance to Market Makers groups                    |
//+------------------------------------------------------------------+
int CMarketMakersBase::UserCheck(const UserInfo *user)
  {
   double max_free_margin=LONG_MIN,margin=0,freemargin=0,equity=0;
   int    selected_maker =-1;
//---
   if(user!=NULL)
      for(int i=0;i<m_makers_total;i++)
        {
         if(user->login==m_makers[i].info.login) break;
         if(CheckGroup(m_makers[i].groups,(LPSTR)user->group)==FALSE) continue;
         ExtServer->TradesMarginInfo(&m_makers[i].info,&margin,&freemargin,&equity);
         if(freemargin>max_free_margin) { selected_maker=i; max_free_margin=freemargin; }
        }
//---
   return(selected_maker);
  }
//+------------------------------------------------------------------+
//| Search symbols spread                                            |
//+------------------------------------------------------------------+
int CMarketMakersBase::SymbolSpread(const MarketMaker* maker,const char* symbol)
  {
   SymbolInfo *info;
//---
   if(symbol!=NULL && maker!=NULL)
      if((info=(SymbolInfo*)bsearch(symbol,maker->symbols,maker->symbols_total,sizeof(SymbolInfo),SearchBySymbol))!=NULL)
         return(info->spread);
//---
   return(0);
  }
//+------------------------------------------------------------------+
//| Check and add hedging order                                      |
//+------------------------------------------------------------------+
void CMarketMakersBase::TradeAdd(TradeRecord *trade,UserInfo *user,const ConSymbol *symb)
  {
   TradeRecord  mirror_trade={0};
   MarketMaker *maker;
   int          index,hedge_order,spread;
   DWORD        thread_id;
   UserRecord   mm_user;
//--- check parameters
   if(trade==NULL || user==NULL || symb==NULL || ExtServer==NULL) return;
//--- process only BUY and SELL trades
   if(trade->cmd!=OP_BUY && trade->cmd!=OP_SELL) return;
//--- check if this is cyclic hook
   if((thread_id=GetCurrentThreadId())==trade->internal_id)  return;
   m_sync.Lock();
//--- check client group
   if((index=UserCheck(user))<0) { m_sync.Unlock(); return; }
//--- update market maker account
   maker=&m_makers[index];
   if(ExtServer->ClientsUserInfo(maker->info.login,&mm_user)==FALSE) { m_sync.Unlock(); return; }
   maker->info.balance =mm_user.balance;
   maker->info.credit  =mm_user.credit;
   maker->info.leverage=mm_user.leverage;
//--- fill order
   memcpy(&mirror_trade,trade,sizeof(TradeRecord));
   mirror_trade.order =0;
   mirror_trade.login =maker->info.login;
   mirror_trade.sl    =0;
   mirror_trade.tp    =0;
   mirror_trade.profit=0;
   mirror_trade.magic =trade->order;
   mirror_trade.internal_id=thread_id;
//--- search spread difference
   spread=SymbolSpread(maker,symb->symbol);
//---
   if(trade->cmd==OP_BUY)
     {
      mirror_trade.cmd=OP_SELL;
      mirror_trade.open_price=trade->open_price-NormalizeDouble(spread*Points(symb->digits),symb->digits);
     }
   else
     {
      mirror_trade.cmd=OP_BUY;
      mirror_trade.open_price=trade->open_price+NormalizeDouble(spread*Points(symb->digits),symb->digits);
     }
   mirror_trade.cmd=(trade->cmd==OP_BUY) ? OP_SELL : OP_BUY;
//--- save mirror order in trade's internal_id
   _snprintf(mirror_trade.comment,sizeof(mirror_trade.comment)-1,"hedge for #%d",trade->order);
//--- add it to base
   if((hedge_order=ExtServer->OrdersAdd(&mirror_trade,&maker->info,symb))>0)
      if(TradeAddCache(trade->order,hedge_order,maker)==FALSE)
        {
         //--- delete hedged trade
         mirror_trade.order=hedge_order;
         ExtServer->OrdersUpdate(&mirror_trade,&maker->info,UPDATE_DELETE);
         ExtLogger.Out("HedgeBase: cache inserting error for #%d, order #%d deleted",trade->order,mirror_trade.order);
         //---
         m_sync.Unlock();
         return;
        }
   m_sync.Unlock();
//--- report results
   ExtLogger.Out("HedgeBase: open #%d on '%d' for #%d on '%d'",hedge_order,maker->info.login,trade->order,trade->login);
  }
//+------------------------------------------------------------------+
//| Add trade to cache                                               |
//+------------------------------------------------------------------+
int CMarketMakersBase::TradeAddCache(const int order,const int hedge_order,MarketMaker *maker)
  {
   OrdersPair  *newbuf,pair;
//---
   if(maker==NULL) return(FALSE);
//--- check memory
   if(m_orders_total>=m_orders_max || m_orders==NULL)
     {
      if((newbuf=new OrdersPair[m_orders_total+512])==NULL)
        {
         return(FALSE);
        }
      if(m_orders!=NULL)
        {
         if(m_orders_total>0) memcpy(newbuf,m_orders,sizeof(OrdersPair)*m_orders_total);
         delete[] m_orders;
        }
      m_orders    =newbuf;
      m_orders_max=m_orders_total+512;
     }
//--- add hedged pair
   pair.order       =order;
   pair.hedge_order =hedge_order;
   pair.market_maker=maker;
   if(insert(m_orders,&pair,m_orders_total,sizeof(OrdersPair),SortByOrder)==NULL)
      return(FALSE);
//---
   m_orders_total++;
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| Find hedged order and close it                                   |
//+------------------------------------------------------------------+
void CMarketMakersBase::TradeClose(TradeRecord *trade,UserInfo *user,const int mode)
  {
   DWORD        thread_id;
   int          index,spread;
   OrdersPair  *pair;
   MarketMaker *maker;
   TradeRecord  hedge_trade={0};
   UserRecord   mm_user;
//--- check parameters
   if(trade==NULL || user==NULL || ExtServer==NULL) return;
//--- we don't need usual modification
   if(mode==UPDATE_NORMAL) return;
//--- process only BUY and SELL trades
   if(trade->cmd!=OP_BUY && trade->cmd!=OP_SELL) return;
//--- check if this is cyclic hook
   if((thread_id=GetCurrentThreadId())==trade->internal_id)  return;
//--- this is activation of opened order?
   if(mode==UPDATE_ACTIVATE)
     {
      ConSymbol sec={0};
      ExtServer->SymbolsGet(trade->symbol,&sec);
      TradeAdd(trade,user,&sec);
      return;
     }
//---
   m_sync.Lock();
//--- find info...
   if(m_orders!=NULL && (pair=(OrdersPair*)bsearch(&trade->order,m_orders,m_orders_total,sizeof(OrdersPair),SearchByOrder))!=NULL)
     {
      //--- update market maker account info
      maker=pair->market_maker;
      if(ExtServer->ClientsUserInfo(maker->info.login,&mm_user)==FALSE) { m_sync.Unlock(); return; }
      maker->info.balance =mm_user.balance;
      maker->info.credit  =mm_user.credit;
      maker->info.leverage=mm_user.leverage;
      //--- finf order
      if(ExtServer->OrdersGet(pair->hedge_order,&hedge_trade)!=FALSE || strcmp(trade->symbol,hedge_trade.symbol)!=0)
        {
         //--- search spread difference
         spread=SymbolSpread(maker,trade->symbol);
         //--- prepare hedge trade
         hedge_trade.volume     =trade->volume;
         hedge_trade.close_time =trade->close_time;
         hedge_trade.internal_id=thread_id;
         //--- change price
         if(hedge_trade.cmd==OP_BUY)
            hedge_trade.close_price=trade->close_price-NormalizeDouble(spread*Points(trade->digits),trade->digits);
         else
            hedge_trade.close_price=trade->close_price+NormalizeDouble(spread*Points(trade->digits),trade->digits);
         //--- calc order profit
         if(mode==UPDATE_CLOSE) ExtServer->TradesCalcProfit(maker->info.group,&hedge_trade);
         else
           {
            hedge_trade.profit=0;
            hedge_trade.commission=0;
            hedge_trade.storage=0;
           }
         //--- close hedged order
         if(ExtServer->OrdersUpdate(&hedge_trade,&maker->info,mode)==FALSE)
            ExtLogger.Out("HedgeBase: hedge order #%d closing error",pair->hedge_order,pair->order);
         else
            ExtLogger.Out("HedgeBase: hedge order #%d on '%d' for #%d on '%d' closed",pair->hedge_order,hedge_trade.login,
                                                                                      pair->order,trade->login);
        }
      else ExtLogger.Out("HedgeBase: hedge order #%d finding error for #%d [server]",pair->hedge_order,pair->order);
      //--- remove pair from buffer
      index=pair-m_orders;
      if((index+1)<m_orders_total) memmove(pair,pair+1,sizeof(OrdersPair)*(m_orders_total-index-1));
      m_orders_total--;
     }
   else ExtLogger.Out("HedgeBase: no hedge order for #%d",trade->order);
//---
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+

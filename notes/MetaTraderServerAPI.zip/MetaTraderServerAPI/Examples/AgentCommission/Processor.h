//+------------------------------------------------------------------+
//|                                      MetaTrader Agent Commission |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once

//+------------------------------------------------------------------+
//| Agent commission for volume range                               |
//+------------------------------------------------------------------+
struct Commission
  {
   int               volume_min;          // min
   int               volume_max;          // max
   double            mult;                // multiplier for commission
  };
//+------------------------------------------------------------------+
//| Max Paoyot for currency                                          |
//+------------------------------------------------------------------+
struct MaxPayot
  {
   char              currency[16];        // currency
   double            value;               // value
  };
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
class CProcessor
  {
private:
   CSync             m_sync;              // synchronizer
   char              m_groups[256];       // groups
   char              m_symbols[256];      // symbols
   int               m_min_points;        // minimal profit/loss for deal
   MaxPayot         *m_payots;            // max payots
   int               m_payots_total;      // amount of max payots
   Commission       *m_commissions;       // commissions
   int               m_commissions_total; // amount of commissions

public:
                     CProcessor();
                    ~CProcessor();
   //--- initializing
   int               Initialize(void);
   //--- agent commission process
   int               AgentCommission(TradeRecord *trade,const UserInfo* user);

private:
   //--- commissions base loading
   int               CommissionsLoad(void);
   //--- max payots base loading
   int               MaxPayotsLoad(void);
   //--- 
   double            MaxPayotsGet(LPCSTR currency) const;
   //--- out to server log
   void              Out(const int code,LPCSTR ip,LPCSTR msg,...) const;
   //--- sorting
   static int        CommissionsSort(const void *param1,const void *param2);

  };
//---
extern CProcessor ExtProcessor;
//+------------------------------------------------------------------+

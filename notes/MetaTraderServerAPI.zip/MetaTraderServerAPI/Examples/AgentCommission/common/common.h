//+------------------------------------------------------------------+
//|                                      MetaTrader Agent Commission |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double __fastcall NormalizeDouble(const double val, int digits);
double            DecPow(const int digits);
int               GetCurrencyDigits(LPCSTR currency);
int               CheckGroup(char* grouplist,const char *group);
//+------------------------------------------------------------------+

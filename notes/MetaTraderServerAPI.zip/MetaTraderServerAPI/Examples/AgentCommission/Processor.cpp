//+------------------------------------------------------------------+
//|                                      MetaTrader Agent Commission |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
#include "Processor.h"
//--- link to Server interface 
extern CServerInterface *ExtServer;
//--- our processor
CProcessor               ExtProcessor;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CProcessor::CProcessor() : m_min_points(0),
                           m_payots(NULL),
                           m_payots_total(0),
                           m_commissions(NULL),
                           m_commissions_total(0)
  {
   COPY_STR(m_groups, "");
   COPY_STR(m_symbols,"");
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CProcessor::~CProcessor()
  {
//--- lock
   m_sync.Lock();
//--- delete all
   if(m_commissions!=NULL) { delete[] m_commissions; m_commissions=NULL; }
   if(m_payots     !=NULL) { delete[] m_payots;      m_payots     =NULL; }
//--- set all to zero
   m_commissions_total=m_payots_total=0;
//--- unlock
   m_sync.Unlock();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::Initialize(void)
  {
//--- lock
   m_sync.Lock();
//--- receive main parameters
   ExtConfig.GetString(1,"Groups", m_groups, sizeof(m_groups)-1, ",*,");
   ExtConfig.GetString(2,"Symbols",m_symbols,sizeof(m_symbols)-1,",*,");
//--- receive limit for mininal trade pips
   ExtConfig.GetInteger(3,"Min Trade Points",&m_min_points,"0");
//--- load payots base and commissions base
   if(MaxPayotsLoad()==FALSE || CommissionsLoad()==FALSE)
     {
      m_sync.Unlock();
      return(TRUE);
     }
//--- unlock
   m_sync.Unlock();
//--- ok
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::CommissionsLoad(void)
  {
   int          i,commissions_max=m_commissions_total;
   PluginCfg    cfg;
   Commission   commission,*temp;
   char        *cp;
//--- delete all commissions
   m_commissions_total=0;
//--- go through parameters
   for(i=0;ExtConfig.Next(i,&cfg)!=FALSE;i++)
      if(strncmp(cfg.name,"Volume",6)==0 && cfg.name[6]!=0)
        {
         //--- receive minimal volume
         commission.volume_min=(int)(atof(cfg.name+7)*100);
         //--- receive maximal volume
         if((cp=strchr(cfg.name+7,'-'))!=NULL) commission.volume_max=(int)(atof(cp+1)*100);
         else                                  commission.volume_max=INT_MAX;
         //--- receive multiplier
         commission.mult=atof(cfg.value);
         //--- checks
         if(commission.mult<0 || commission.volume_min>=commission.volume_max)
           {
            //--- delete invalid config
            ExtConfig.Delete(cfg.name);
            //--- correct index
            i--;
            //--- go to next
            continue;
           }
         //--- check space
         if(m_commissions==NULL || m_commissions_total>=commissions_max)
           {
            //--- allocate larger buffer
            if((temp=new Commission[m_commissions_total+1024])==NULL)
              {
               Out(CmdAtt,"AgentCommission","not enough memory for %d records",m_commissions_total+1024);
               return(FALSE);
              }
            //--- if old buffer exists then delete it
            if(m_commissions!=NULL)
              {
               //--- copy data from old buffer to the new buffer
               memcpy(temp,m_commissions,sizeof(Commission)*m_commissions_total);
               //--- delete old buffer
               delete[] m_commissions;
              }
            //--- set new buffer
            m_commissions  =temp;
            commissions_max=m_commissions_total+1024;
           }
         //--- ������� ������
         memcpy(&m_commissions[m_commissions_total++],&commission,sizeof(Commission));
         //--- delete config
         ExtConfig.Delete(cfg.name);
         //--- correct index
         i--;
        }
//--- sort commissions by minimal volume
   qsort(m_commissions,m_commissions_total,sizeof(Commission),CommissionsSort);
//--- normalizing volumes
   for(i=0;i<m_commissions_total;i++)
     {
      //--- checks
      if(i<m_commissions_total-1)
         if(m_commissions[i].volume_max>m_commissions[i+1].volume_min)
            m_commissions[i].volume_max=m_commissions[i+1].volume_min;
      //--- create new valid config
      _snprintf(cfg.name,sizeof(cfg.name)-1,"Volume %.2f-%.2f",
                m_commissions[i].volume_min/100.0,m_commissions[i].volume_max/100.0);
      _snprintf(cfg.value,sizeof(cfg.value)-1,"%.2f",m_commissions[i].mult);
      //--- add it
      ExtConfig.Add(0,&cfg);
     }
//--- if not exits parameters then create examples
   if(m_commissions_total==0)
     {
      //--- prepare example
      COPY_STR(cfg.value,"1");
      //--- first example
      COPY_STR(cfg.name,"Volume 0.10-1.00");
      ExtConfig.Add(0,&cfg);
      //--- second example
      COPY_STR(cfg.name,"Volume 1.00-10.00");
      ExtConfig.Add(0,&cfg);
     }
//--- ok
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::MaxPayotsLoad(void)
  {
   PluginCfg cfg;
   int       i,payots_max=m_payots_total;
   MaxPayot  payot,*temp;
//--- delete all payots
   m_payots_total=0;
//--- go through parameters
   for(i=0;ExtConfig.Next(i,&cfg)!=FALSE;i++)
      if(strncmp(cfg.name,"Max Agent Payout",16)==0 && cfg.name[16]!=0)
        {
         //--- receive currency
         COPY_STR(payot.currency,cfg.name+17);
         //--- receive value
         payot.value=atof(cfg.value);
         //--- check
         if(payot.currency[0]==0)
           {
            //--- delete invalid config
            ExtConfig.Delete(cfg.name);
            //--- correct index
            i--;
            //--- go to next
            continue;
           }
         //--- check space
         if(m_payots==NULL || m_payots_total>=payots_max)
           {
            //--- allocate larger buffer
            if((temp=new MaxPayot[m_payots_total+1024])==NULL)
              {
               Out(CmdAtt,"AgentCommission","not enough memory for %d records",m_payots_total+1024);
               return(FALSE);
              }
            //--- if old buffer exists then delete it
            if(m_payots!=NULL)
              {
               //--- copy data from old buffer to the new buffer
               memcpy(temp,m_payots,sizeof(MaxPayot)*m_payots_total);
               //--- delete old
               delete[] m_payots;
              }
            //--- set new buffer
            m_payots   =temp;
            payots_max+=m_payots_total+1024;
           }
         //--- add
         memcpy(&m_payots[m_payots_total++],&payot,sizeof(MaxPayot));
        }
//--- if not exits parameters then create examples
   if(m_payots_total==0)
     {
      //--- prepare example
      COPY_STR(cfg.value,"0");
      //--- for USD
      COPY_STR(cfg.name,"Max Agent Payout USD");
      ExtConfig.Add(0,&cfg);
      //--- for EUR
      COPY_STR(cfg.name,"Max Agent Payout EUR");
      ExtConfig.Add(0,&cfg);
     }
//--- ok
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::AgentCommission(TradeRecord *trade,const UserInfo* user)
  {
   int         i;
   Commission *commission;
   double      max_payout=0;
//--- checks
   if(trade==NULL || user==NULL) return(FALSE);
//--- lock
   m_sync.Lock();
//--- check trade
   if(CheckGroup(m_groups,user->group)==FALSE || CheckGroup(m_symbols,trade->symbol)==FALSE)
     {
      m_sync.Unlock();
      return(TRUE);
     }
//--- check minimal pips for trade
   if(m_min_points!=0)
     {
      //--- calc trade profit in pips
      i=(int)NormalizeDouble(DecPow(trade->digits)*(trade->close_price-trade->open_price),0);
      //--- if profit small then commission = 0
      if(abs(i)<m_min_points) { m_sync.Unlock(); return(FALSE); }
     }
//--- find volume range
   for(i=0,commission=m_commissions;i<m_commissions_total;i++,commission++)
      if(trade->volume>=commission->volume_min && trade->volume<=commission->volume_max)
        {
         //--- correct agent commission
         trade->commission_agent*=commission->mult;
         //--- normalization
         trade->commission_agent=NormalizeDouble(trade->commission_agent,GetCurrencyDigits(user->grp.currency));
         //--- break
         break;
        }
//--- check max payot
   if((max_payout=MaxPayotsGet(user->grp.currency))!=0)
      if(trade->commission_agent>max_payout) trade->commission_agent=max_payout;
//--- unlock
   m_sync.Unlock();
//--- ok
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double CProcessor::MaxPayotsGet(LPCSTR currency) const
  {
   int i;
//--- check
   if(currency==NULL || m_payots==NULL || m_payots_total==0) return(0);
//--- find currency
   for(i=0;i<m_payots_total;i++)
      if(strcmp(m_payots[i].currency,currency)==0)
         return(m_payots[i].value);
//--- by default it is 0
   return(0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CProcessor::Out(const int code,LPCSTR ip,LPCSTR msg,...) const
  {
   char buffer[1024];
//--- check
   if(ExtServer==NULL || msg==NULL) return;
//--- format string
   va_list arg_ptr;
   va_start(arg_ptr,msg);
   _vsnprintf(buffer,sizeof(buffer)-1,msg,arg_ptr);
   va_end(arg_ptr);
//--- out to server log
   ExtServer->LogsOut(code,ip,buffer);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int CProcessor::CommissionsSort(const void *param1,const void *param2)
  {
   return((Commission *)param1)->volume_min-((Commission *)param2)->volume_min;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+


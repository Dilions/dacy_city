//+------------------------------------------------------------------+
//|                                                    DealerChecker |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#include "stdafx.h"
//---
PluginInfo        ExtPluginInfo={ "DealerChecker",200,"MetaQuotes Software Corp.",{0} };
CServerInterface *ExtServer=NULL;
//+------------------------------------------------------------------+
//| DLL entry point                                                  |
//+------------------------------------------------------------------+
BOOL APIENTRY DllMain(HANDLE hModule,DWORD  ul_reason_for_call,LPVOID /*lpReserved*/)
  {
   char tmp[256],*cp;
//---
   switch(ul_reason_for_call)
     {
      case DLL_PROCESS_ATTACH:
         //--- ���������� ��� ��������
         GetModuleFileName((HMODULE)hModule,tmp,sizeof(tmp)-5);
         if((cp=strrchr(tmp,'.'))!=NULL)
           {
            *cp=0;
            COPY_STR(ExtProgramPath,tmp);
            strcat(tmp,".ini");
           }
         //--- ��������
         ExtConfig.Load(tmp);
         break;

      case DLL_THREAD_ATTACH:
      case DLL_THREAD_DETACH:
         break;

      case DLL_PROCESS_DETACH:
         break;

      default:
         break;
     }
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| About, must be present always!                                   |
//+------------------------------------------------------------------+
void APIENTRY MtSrvAbout(PluginInfo *info)
  {
   if(info!=NULL) memcpy(info,&ExtPluginInfo,sizeof(PluginInfo));
  }
//+------------------------------------------------------------------+
//| Set server interface point                                       |
//+------------------------------------------------------------------+
int APIENTRY MtSrvStartup(CServerInterface *server)
  {
//--- check version
   if(server==NULL)                        return(FALSE);
   if(server->Version()!=ServerApiVersion) return(FALSE);
//--- �������� ��������� �� ������
   ExtServer=server;
//--- �����������
   ExtReqDispatcher.Initialize();
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//| �������                                                          |
//+------------------------------------------------------------------+
void APIENTRY MtSrvCleanup(void)
  {
//---
//---
  }
//+------------------------------------------------------------------+
//| ������� ������������ �������                                     |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgAdd(const PluginCfg *cfg)
  {
   int res=ExtConfig.Add(cfg);
//--- ���������������
   ExtReqDispatcher.Initialize();
//---
   return(res);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgSet(const PluginCfg *values,const int total)
  {
   int res=ExtConfig.Set(values,total);
//--- ���������������
   ExtReqDispatcher.Initialize();
//---
   return(res);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgDelete(LPCSTR name)
  {
   int res=ExtConfig.Delete(name);
//--- ���������������
   ExtReqDispatcher.Initialize();
//---
   return(res);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgGet(LPCSTR name,PluginCfg *cfg)              { return ExtConfig.Get(name,cfg);        }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgNext(const int index,PluginCfg *cfg)         { return ExtConfig.Next(index,cfg);      }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvPluginCfgTotal()                                      { return ExtConfig.Total();              }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvDealerGet(const ConManager *manager,const RequestInfo *request)
  {
//---
   ExtReqDispatcher.DealerGet(manager->login,request);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvDealerPrice(const int id,const UserInfo *us,double *prices,const int prices_mode)
  {
//---
   ExtReqDispatcher.DealerPrice(id,prices);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvDealerConfirm(const int id,const UserInfo *us,double *prices)
  {
//---
   ExtReqDispatcher.DealerConfirm(id,prices);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvDealerReset(const int id,const UserInfo *us,const char flag)
  {
//---
   ExtReqDispatcher.DealerReset(id);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int APIENTRY MtSrvDealerRequote(const int id,const UserInfo *us,double *prices,const int prices_mode)
  {
//---
   ExtReqDispatcher.DealerRequote(id);
//---
   return(TRUE);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void APIENTRY MtSrvService(DWORD currtime)
  {
//---
   ExtReqDispatcher.Service();
//---
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
